'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kuri-test-'));
process.env.KURI_DATA_DIR = tmp;
process.env.KURI_DEV_OTP = '1';
process.env.ADMIN1_PHONE = '9000000001'; process.env.ADMIN2_PHONE = '9000000002';
process.env.ADMIN_INITIAL_PASSWORD = 'InitialPass123';

const { openDb } = require('../lib/db');
const C = require('../lib/core');
const WA = require('../lib/whatsapp');
const R = require('../lib/reminders');
const { createServer, bootstrapAdmins } = require('../server');

let base, db, server;
class Client {
  constructor() { this.cookie = ''; }
  async call(method, url, body, headers = {}) {
    const res = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'kuri', ...(this.cookie ? { Cookie: this.cookie } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
    const sc = res.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0];
    const ct = res.headers.get('content-type') || '';
    const data = ct.includes('json') ? await res.json() : Buffer.from(await res.arrayBuffer());
    return { status: res.status, data };
  }
  get(u) { return this.call('GET', u); }
  post(u, b) { return this.call('POST', u, b || {}); }
  put(u, b) { return this.call('PUT', u, b); }
  patch(u, b) { return this.call('PATCH', u, b); }
}
const ok = (r, msg) => assert.equal(r.status, 200, `${msg || ''} -> ${r.status} ${JSON.stringify(r.data).slice(0, 300)}`);

const admin = new Client(), admin2 = new Client();
const members = {};
const ids = {};

test.before(async () => {
  db = openDb();
  bootstrapAdmins(db);
  server = createServer(db);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
});
test.after(() => { server.close(); });

const sessions = {};
async function memberLogin(phone) {
  if (sessions[phone]) return sessions[phone]; // reuse: OTP requests are rate limited per phone (5/hour)
  const c = new Client();
  const r = await c.post('/api/auth/otp/request', { phone });
  ok(r, 'otp request');
  const v = await c.post('/api/auth/otp/verify', { phone, code: r.data.dev_otp });
  ok(v, 'otp verify');
  return (sessions[phone] = c);
}

test('admin login forces password change, then works', async () => {
  let r = await admin.post('/api/auth/admin/login', { phone: '9000000001', password: 'wrong' });
  assert.equal(r.status, 401);
  r = await admin.post('/api/auth/admin/login', { phone: '9000000001', password: 'InitialPass123' });
  ok(r); assert.equal(r.data.must_change_pw, true);
  r = await admin.get('/api/admin/dashboard');
  assert.equal(r.status, 403); assert.equal(r.data.code, 'password_change_required');
  r = await admin.post('/api/auth/admin/change-password', { current: 'InitialPass123', new: 'short' });
  assert.equal(r.status, 400);
  r = await admin.post('/api/auth/admin/change-password', { current: 'InitialPass123', new: 'BetterPass12345' });
  ok(r);
  ok(await admin.get('/api/admin/dashboard'));
  ok(await admin2.post('/api/auth/admin/login', { phone: '9000000002', password: 'InitialPass123' }));
  ok(await admin2.post('/api/auth/admin/change-password', { current: 'InitialPass123', new: 'AnotherPass12345' }));
});

test('CSRF header and anonymous access are enforced', async () => {
  const anon = new Client();
  assert.equal((await anon.get('/api/admin/members')).status, 401);
  assert.equal((await anon.get('/api/me/overview')).status, 401);
  const raw = await fetch(base + '/api/auth/otp/request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(raw.status, 403);
});

test('settings are editable and validated (nothing hard-coded)', async () => {
  const d = new Date(Date.now() + 330 * 60000);
  d.setUTCMonth(d.getUTCMonth() - 2); d.setUTCDate(1); // cycle began two months ago
  const start = d.toISOString().slice(0, 10);
  let r = await admin.put('/api/admin/settings', { total_entries: 0 });
  assert.equal(r.status, 400);
  r = await admin.put('/api/admin/settings', { total_entries: 3, monthly_contribution: 20000, duration_months: 6, winning_entries_per_draw: 1, prize_amount: 60000, start_date: start, due_day: 5, draw_day: 10, winner_privacy: 'masked' });
  ok(r); assert.equal(r.data.total_entries, 3); assert.equal(r.data.prize_amount, 60000);
  assert.equal((await admin.put('/api/admin/settings', { bogus: 1 })).status, 400);
});

test('members: add, validate, duplicate phone rejected', async () => {
  const defs = { A: ['Anil Kumar', '9100000001'], B: ['Bindu Nair', '9100000002'], C: ['Chandran', '9100000003'], D: ['Divya', '9100000004'], E: ['Eldho', '9100000005'], F: ['Fathima', '9100000006'] };
  for (const [k, [name, phone]] of Object.entries(defs)) {
    const r = await admin.post('/api/admin/members', { name, phone, address: 'Kochi', registration_details: 'ID ' + k });
    ok(r); ids[k] = r.data.id; members[k] = '+91' + phone;
  }
  assert.equal((await admin.post('/api/admin/members', { name: 'Dup', phone: '9100000001' })).status, 400);
  assert.equal((await admin.post('/api/admin/members', { name: 'X', phone: 'abc' })).status, 400);
});

test('entries: individual + team counts as ONE entry; sums validated', async () => {
  ok(await admin.post('/api/admin/entries', { type: 'individual', members: [{ member_id: ids.A }] }), 'entry A');
  ok(await admin.post('/api/admin/entries', { type: 'individual', members: [{ member_id: ids.B }] }), 'entry B');
  // wrong contribution sum
  let r = await admin.post('/api/admin/entries', { type: 'team', members: [{ member_id: ids.C, monthly_share: 5000, prize_percent: 50 }, { member_id: ids.D, monthly_share: 5000, prize_percent: 50 }] });
  assert.equal(r.status, 400); assert.match(r.data.error, /add up/);
  // wrong percentage sum
  r = await admin.post('/api/admin/entries', { type: 'team', members: [4, 4, 4, 4].map((_, i) => ({ member_id: [ids.C, ids.D, ids.E, ids.F][i], monthly_share: 5000, prize_percent: 20 })) });
  assert.equal(r.status, 400); assert.match(r.data.error, /100/);
  r = await admin.post('/api/admin/entries', { type: 'team', name: 'Team Kochi', members: [
    { member_id: ids.C, monthly_share: 5000, prize_percent: 40 }, { member_id: ids.D, monthly_share: 5000, prize_percent: 30 },
    { member_id: ids.E, monthly_share: 5000, prize_percent: 20 }, { member_id: ids.F, monthly_share: 5000, prize_percent: 10 }] });
  ok(r, 'team'); ids.team = r.data.id;
  // capacity (3 entries) reached
  r = await admin.post('/api/admin/members', { name: 'Extra', phone: '9100000009' }); ids.X = r.data.id;
  r = await admin.post('/api/admin/entries', { type: 'individual', members: [{ member_id: ids.X }] });
  assert.equal(r.status, 400);
  const list = (await admin.get('/api/admin/entries')).data;
  assert.equal(list.length, 3);
  const dash = (await admin.get('/api/admin/dashboard')).data;
  assert.equal(dash.entries.total, 3); assert.equal(dash.entries.teams, 1);
  ids.entryA = list[0].id; ids.entryB = list[1].id;
});

test('cycle generated from settings', async () => {
  const r = await admin.post('/api/admin/cycle/generate');
  ok(r); assert.equal(r.data.length, 6);
  assert.ok(r.data[0].due_date < r.data[0].draw_date);
});

test('member OTP login: only registered phones; strict data isolation', async () => {
  const unk = new Client();
  const r = await unk.post('/api/auth/otp/request', { phone: '9999999999' });
  ok(r); assert.equal(r.data.dev_otp, undefined); // unregistered numbers get no OTP
  assert.equal((await unk.post('/api/auth/otp/verify', { phone: '9999999999', code: '123456' })).status, 401);

  const a = await memberLogin(members.A), b = await memberLogin(members.B);
  const oa = (await a.get('/api/me/overview')).data, ob = (await b.get('/api/me/overview')).data;
  assert.equal(oa.member.name, 'Anil Kumar'); assert.equal(ob.member.name, 'Bindu Nair');
  assert.ok(!JSON.stringify(oa).includes('Bindu') && !JSON.stringify(oa).includes('9100000002'));
  assert.equal((await a.get('/api/admin/members')).status, 401); // members cannot reach admin API
  // wrong OTP & replay
  const c = new Client(); const q = await c.post('/api/auth/otp/request', { phone: members.A });
  assert.equal((await c.post('/api/auth/otp/verify', { phone: members.A, code: q.data.dev_otp === '000000' ? '111111' : '000000' })).status, 401);
});

test('team member sees own share only, not teammates\' payments or UPI', async () => {
  const c = await memberLogin(members.C), d = await memberLogin(members.D);
  ok(await d.post('/api/me/upi', { upi_id: 'divya@okbank' }));
  const oc = (await c.get('/api/me/overview')).data;
  assert.equal(oc.entries.length, 1);
  assert.equal(oc.entries[0].my_share, 5000); assert.equal(oc.entries[0].my_prize_percent, 40);
  assert.equal(oc.entries[0].team.length, 4);
  assert.ok(!JSON.stringify(oc).includes('divya@okbank'));
  assert.equal((await c.get('/api/me/upi/qr')).status, 404);
});

test('payments: submit, validation, duplicates, admin verification updates balances', async () => {
  const a = await memberLogin(members.A);
  let r = await a.post('/api/me/payments', { entry_id: ids.entryA, month_no: 1, amount: 25000, txn_ref: 'UTR000000001' });
  assert.equal(r.status, 400); // overpay
  r = await a.post('/api/me/payments', { entry_id: ids.entryA, month_no: 1, amount: 20000 });
  assert.equal(r.status, 400); // txn ref required
  r = await a.post('/api/me/payments', { entry_id: ids.entryB, month_no: 1, amount: 20000, txn_ref: 'UTR000000002' });
  assert.equal(r.status, 403); // not their entry
  r = await a.post('/api/me/payments', { entry_id: ids.entryA, month_no: 1, amount: 12000, txn_ref: 'UTR000000003' });
  ok(r); const pid = r.data.id;
  let ov = (await a.get('/api/me/overview')).data.entries[0].ledger[0];
  assert.equal(ov.paid, 0); assert.equal(ov.pending, 12000); assert.equal(ov.remaining, 20000); // submission alone is NOT payment
  r = await a.post('/api/me/payments', { entry_id: ids.entryA, month_no: 1, amount: 1000, txn_ref: 'utr000000003' });
  assert.equal(r.status, 400); // duplicate ref (case-insensitive)
  ok(await admin.post(`/api/admin/payments/${pid}/verify`));
  assert.equal((await admin.post(`/api/admin/payments/${pid}/verify`)).status, 400); // no double verify
  ov = (await a.get('/api/me/overview')).data.entries[0].ledger[0];
  assert.equal(ov.paid, 12000); assert.equal(ov.remaining, 8000);
  assert.equal((await a.get('/api/me/notifications')).data[0].type, 'payment_confirmed');
  // rejected payment frees the txn ref and leaves balance unchanged
  r = await a.post('/api/me/payments', { entry_id: ids.entryA, month_no: 1, amount: 8000, txn_ref: 'UTR000000004' }); ok(r);
  ok(await admin.post(`/api/admin/payments/${r.data.id}/reject`, { reason: 'Reference not found in bank statement' }));
  assert.equal((await a.get('/api/me/overview')).data.entries[0].ledger[0].remaining, 8000);
});

test('UPI QR upload is validated, private, and admin-reviewed', async () => {
  const b = await memberLogin(members.B);
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), crypto.randomBytes(64)]).toString('base64');
  assert.equal((await b.post('/api/me/upi', { upi_id: 'not a upi', qr_base64: png })).status, 400);
  assert.equal((await b.post('/api/me/upi', { upi_id: 'bindu@okaxis', qr_base64: Buffer.from('<script>alert(1)</script>').toString('base64') })).status, 400);
  const r = await b.post('/api/me/upi', { upi_id: 'bindu@okaxis', qr_base64: png });
  ok(r); assert.equal(r.data.upi_status, 'pending');
  const own = await b.get('/api/me/upi/qr'); assert.equal(own.status, 200);
  const a = await memberLogin(members.A);
  assert.equal((await a.get(`/api/admin/members/${ids.B}/qr`)).status, 401); // other members cannot
  ok(await admin.get(`/api/admin/members/${ids.B}/qr`));
  assert.equal((await admin.post(`/api/admin/members/${ids.B}/upi-review`, { approve: false })).status, 400); // reason required
  const rv = await admin.post(`/api/admin/members/${ids.B}/upi-review`, { approve: true }); ok(rv);
  assert.equal(rv.data.upi_status, 'approved');
});

test('reminders: honest delivery states, partial payments, auto-stop on full payment', async () => {
  // B has not opted in and WhatsApp is unconfigured -> messages must be FAILED, never "sent"
  let r = await admin.post('/api/admin/reminders', { entry_id: ids.entryB, month_no: 1, interval_days: 3, period_months: 12 });
  ok(r); const rid = r.data.id;
  assert.equal(r.data.outstanding_now, 20000);
  assert.ok(Date.parse(r.data.end_date) > Date.now() + 300 * 864e5); // ~1 year period
  const future = () => new Date(Date.now() + 2 * 864e5);
  await R.tick(db, future());
  let msgs = (await admin.get(`/api/admin/messages?reminder_id=${rid}`)).data;
  assert.equal(msgs.length, 1); assert.equal(msgs[0].status, 'failed'); assert.match(msgs[0].error, /opted in/);
  assert.equal(msgs[0].amount, 20000);

  // opt-in + configured provider with a mocked transport; "accepted" is not "delivered"
  ok(await admin.patch(`/api/admin/members/${ids.B}`, { whatsapp_opt_in: true }));
  process.env.WHATSAPP_TOKEN = 'tkn'; process.env.WHATSAPP_PHONE_ID = '123'; process.env.WHATSAPP_APP_SECRET = 'appsecret'; process.env.WHATSAPP_VERIFY_TOKEN = 'vt';
  const calls = [];
  WA.setTransport(async (url, opts) => { calls.push({ url, body: JSON.parse(opts.body) }); return { ok: true, status: 200, json: async () => ({ messages: [{ id: 'wamid.TEST' + calls.length }] }) }; });
  // pay part of it first -> next message carries only the remaining amount
  ok(await admin.post('/api/admin/payments/record', { entry_id: ids.entryB, member_id: ids.B, month_no: 1, amount: 5000, method: 'cash' }));
  db.prepare('UPDATE reminders SET next_run_at = ? WHERE id = ?').run(new Date(Date.now() - 1000).toISOString(), rid);
  await R.tick(db, new Date());
  msgs = (await admin.get(`/api/admin/messages?reminder_id=${rid}`)).data;
  const latest = msgs[0];
  assert.equal(latest.status, 'accepted'); assert.equal(latest.amount, 15000);
  assert.equal(calls.length, 1); assert.equal(calls[0].body.type, 'template'); assert.equal(calls[0].body.to, '919100000002');
  assert.equal(calls[0].body.template.components[0].parameters[1].text, '15000');

  // webhook: bad signature rejected, valid one upgrades status
  const payload = JSON.stringify({ entry: [{ changes: [{ value: { statuses: [{ id: latest.provider_message_id, status: 'delivered' }] } }] }] });
  let w = await fetch(base + '/webhooks/whatsapp', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Hub-Signature-256': 'sha256=bad' }, body: payload });
  assert.equal(w.status, 401);
  const sig = 'sha256=' + crypto.createHmac('sha256', 'appsecret').update(payload).digest('hex');
  w = await fetch(base + '/webhooks/whatsapp', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Hub-Signature-256': sig }, body: payload });
  assert.equal(w.status, 200);
  assert.equal((await admin.get(`/api/admin/messages?reminder_id=${rid}`)).data[0].status, 'delivered');
  const failPayload = JSON.stringify({ entry: [{ changes: [{ value: { statuses: [{ id: latest.provider_message_id, status: 'failed', errors: [{ title: 'Undeliverable' }] }] } }] }] });
  const sig2 = 'sha256=' + crypto.createHmac('sha256', 'appsecret').update(failPayload).digest('hex');
  await fetch(base + '/webhooks/whatsapp', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Hub-Signature-256': sig2 }, body: failPayload });
  assert.equal((await admin.get(`/api/admin/messages?reminder_id=${rid}`)).data[0].status, 'failed');

  // pause -> no run; resume; manual stop path
  ok(await admin.post(`/api/admin/reminders/${rid}/action`, { action: 'pause' }));
  const before = (await admin.get('/api/admin/messages')).data.length;
  db.prepare('UPDATE reminders SET next_run_at = ? WHERE id = ?').run(new Date(Date.now() - 1000).toISOString(), rid);
  await R.tick(db, new Date());
  assert.equal((await admin.get('/api/admin/messages')).data.length, before);
  ok(await admin.post(`/api/admin/reminders/${rid}/action`, { action: 'resume' }));

  // fully paid -> reminder stops IMMEDIATELY (no waiting for the next tick)
  ok(await admin.post('/api/admin/payments/record', { entry_id: ids.entryB, member_id: ids.B, month_no: 1, amount: 15000, method: 'bank', txn_ref: 'BANKREF0001' }));
  const rem = (await admin.get('/api/admin/reminders')).data.reminders.find((x) => x.id === rid);
  assert.equal(rem.status, 'completed'); assert.equal(rem.stop_reason, 'fully_paid'); assert.equal(rem.next_run_at, null);
  delete process.env.WHATSAPP_TOKEN; delete process.env.WHATSAPP_PHONE_ID;
});

test('reminder schedule math: custom dates, interval, end date', () => {
  const r = { start_date: '2026-01-01', end_date: '2026-01-20', interval_days: 7, custom_dates: JSON.stringify(['2026-01-03']) };
  assert.equal(R.nextRunDate(r, null), '2026-01-01');
  assert.equal(R.nextRunDate(r, '2026-01-01'), '2026-01-03');
  assert.equal(R.nextRunDate(r, '2026-01-03'), '2026-01-08');
  assert.equal(R.nextRunDate(r, '2026-01-15'), null); // next would be Jan 22 > end
});

test('draw: eligibility rules, secure draw, verifiable, immutable, one team = one entry', async () => {
  // Pay everything for months 1-3 so entries are eligible for draw rules; leave team member F short in month 2
  const entries = (await admin.get('/api/admin/entries')).data;
  const months = (await admin.get('/api/admin/months')).data;
  const today = C.todayLocal();
  const dueMonths = months.filter((m) => m.draw_date <= today).map((m) => m.month_no);
  assert.ok(dueMonths.length >= 2, 'test cycle should have at least two drawable months');
  for (const e of entries) for (const m of e.members) for (const mn of dueMonths) {
    const bal = (await admin.get('/api/admin/payments')).data; // keep API warm
    const exp = m.monthly_share;
    const paid = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM payments WHERE member_id=? AND month_no=? AND status='verified'").get(m.member_id, mn).s;
    if (e.id === ids.team && m.member_id === ids.F && mn === dueMonths[0]) continue; // F skips month 1
    if (paid < exp) ok(await admin.post('/api/admin/payments/record', { entry_id: e.id, member_id: m.member_id, month_no: mn, amount: exp - paid, method: 'cash' }), 'record');
  }
  let el = (await admin.get(`/api/admin/draw/eligibility?month_no=${dueMonths[0]}`)).data;
  assert.equal(el.eligible.length, 2);
  assert.ok(el.excluded.find((x) => x.entry_id === ids.team && x.reason === 'unpaid'));
  assert.equal(el.eligible.some((x) => x.entry_id === ids.team), false);

  // non-admin cannot trigger; month order enforced
  const a = await memberLogin(members.A);
  assert.equal((await a.post('/api/admin/draw/run', { month_no: 1 })).status, 401);
  assert.equal((await admin.post('/api/admin/draw/run', { month_no: dueMonths[1] })).status, 400); // month 1 first
  assert.equal((await admin.post('/api/admin/draw/run', { month_no: 6 })).status, 400); // future draw date
  const d1 = await admin.post('/api/admin/draw/run', { month_no: dueMonths[0] });
  ok(d1, 'draw 1');
  assert.equal(d1.data.winners.length, 1);
  assert.ok([ids.entryA, ids.entryB].includes(d1.data.winners[0]));
  assert.equal((await admin.post('/api/admin/draw/run', { month_no: dueMonths[0] })).status, 400); // no re-draw

  const ver = (await admin.get(`/api/admin/draws/${d1.data.id}/verify`)).data;
  assert.equal(ver.winners_match, true); assert.equal(ver.eligible_hash_matches, true);

  // F catches up; month 2 now: winner of month 1 excluded (one win per entry)
  const fBal = C.memberMonthBalance(db, ids.team, ids.F, dueMonths[0]).remaining;
  ok(await admin.post('/api/admin/payments/record', { entry_id: ids.team, member_id: ids.F, month_no: dueMonths[0], amount: fBal, method: 'cash' }));
  el = (await admin.get(`/api/admin/draw/eligibility?month_no=${dueMonths[1]}`)).data;
  assert.ok(el.excluded.find((x) => x.entry_id === d1.data.winners[0] && x.reason === 'already_won'));
  const d2 = await admin.post('/api/admin/draw/run', { month_no: dueMonths[1] }); ok(d2, 'draw 2');
  assert.notEqual(d2.data.winners[0], d1.data.winners[0]);
  assert.ok([ids.entryA, ids.entryB, ids.team].includes(d2.data.winners[0])); // a whole entry, never an individual team member

  // immutability: even direct SQL cannot rewrite or delete history
  assert.throws(() => db.prepare('UPDATE draws SET winners = ? WHERE id = ?').run('[1]', d1.data.id), /immutable/);
  assert.throws(() => db.prepare('DELETE FROM draws WHERE id = ?').run(d1.data.id), /immutable/);
  assert.throws(() => db.prepare("UPDATE audit_log SET action = 'x' WHERE id = 1").run(), /append-only/);
  ids.d1 = d1.data; ids.d2 = d2.data;
});

test('prizes: team shares follow agreed percentages; privacy applied; payout tracked', async () => {
  const prizes = (await admin.get('/api/admin/prizes')).data;
  assert.equal(prizes.length, 2);
  for (const p of prizes) {
    assert.equal(p.shares.reduce((a, s) => a + s.amount, 0), p.amount); // exact split, no lost rupees
    assert.equal(p.amount, 60000);
  }
  const teamPrize = prizes.find((p) => p.entry_id === ids.team);
  if (teamPrize) assert.deepEqual(teamPrize.shares.map((s) => s.amount), [24000, 18000, 12000, 6000]);

  // member view: others' names are masked, own name shown, entry label visible
  const viewer = await memberLogin(members.C);
  const draws = (await viewer.get('/api/draws')).data;
  assert.equal(draws.length, 2);
  for (const d of draws) for (const w of d.winners) {
    if (w.entry_id === ids.entryA) assert.ok(!w.names.join().includes('Anil'), 'name should be masked: ' + w.names);
  }
  // winner sees own prize details
  const winnerKey = prizes[0].entry_id === ids.entryA ? 'A' : prizes[0].entry_id === ids.entryB ? 'B' : 'C';
  const w = await memberLogin(members[winnerKey]);
  const ov = (await w.get('/api/me/overview')).data;
  assert.ok(ov.entries[0].won); assert.equal(ov.entries[0].won.amount, 60000);
  // public verification of the draw is available to members
  const pv = (await viewer.get(`/api/draws/${draws[0].id}/verify`)).data;
  assert.equal(pv.winners_match, true);

  const paid = await admin.post(`/api/admin/prizes/${prizes[0].id}/paid`, { payment_ref: 'PAYOUT123' });
  ok(paid); assert.equal(paid.data.status, 'paid');
  assert.equal((await admin.post(`/api/admin/prizes/${prizes[0].id}/paid`, {})).status, 400);
});

test('reports: JSON, Excel and PDF exports', async () => {
  for (const name of ['monthly_collection', 'member_payments', 'team_contribution', 'outstanding', 'winners', 'prize_distribution', 'admin_activity']) {
    const r = await admin.get(`/api/admin/reports/${name}`);
    ok(r, name); assert.ok(r.data.columns.length && Array.isArray(r.data.rows));
  }
  const x = await admin.get('/api/admin/reports/winners?format=xlsx'); ok(x);
  assert.equal(x.data.slice(0, 2).toString(), 'PK');
  const p = await admin.get('/api/admin/reports/monthly_collection?format=pdf'); ok(p);
  assert.equal(p.data.slice(0, 4).toString(), '%PDF');
  assert.equal((await admin.get('/api/admin/reports/nonsense')).status, 400);
});

test('configurable admin permissions are enforced', async () => {
  const list = (await admin.get('/api/admin/admins')).data; assert.equal(list.length, 2);
  const a2 = list.find((a) => a.phone === '+919000000002');
  ok(await admin.patch(`/api/admin/admins/${a2.id}`, { permissions: ['members', 'reports'] }));
  const fresh = new Client(); ok(await fresh.post('/api/auth/admin/login', { phone: '9000000002', password: 'AnotherPass12345' }));
  assert.equal((await fresh.get('/api/admin/members')).status, 200);
  assert.equal((await fresh.post('/api/admin/draw/run', { month_no: 3 })).status, 403);
  assert.equal((await fresh.get('/api/admin/audit')).status, 403);
  assert.equal((await fresh.get('/api/admin/reports/admin_activity')).status, 403);
  assert.equal((await fresh.put('/api/admin/settings', { prize_amount: 1 })).status, 403);
  assert.equal((await admin.patch(`/api/admin/admins/${list.find((a) => a.id !== a2.id).id}`, { permissions: ['members'] })).status, 400); // can't remove own manage_admins
});

test('announcements, audit chain and backups', async () => {
  let r = await admin.post('/api/admin/announce', { title: 'Meeting', body: 'Monthly meeting on Sunday' }); ok(r);
  assert.ok(r.data.recipients >= 6);
  const a = await memberLogin(members.A);
  const n = (await a.get('/api/me/notifications')).data;
  assert.ok(n.some((x) => x.type === 'announcement'));
  await a.post('/api/me/notifications/read');
  assert.equal((await a.get('/api/me/overview')).data.unread, 0);
  const au = (await admin.get('/api/admin/audit')).data;
  assert.equal(au.chain.ok, true);
  for (const act of ['settings.update', 'member.add', 'entry.create', 'payment.verify', 'draw.run', 'prize.paid', 'login.admin']) assert.ok(au.rows.some((x) => x.action === act), 'audit has ' + act);
  const b = await admin.post('/api/admin/backups'); ok(b);
  const lst = (await admin.get('/api/admin/backups')).data; assert.ok(lst.length >= 1);
  const dl = await admin.get('/api/admin/backups/' + lst[0].name); ok(dl);
  assert.equal(dl.data.slice(0, 15).toString(), 'SQLite format 3');
  assert.equal((await admin.get('/api/admin/backups/..%2f..%2fetc%2fpasswd')).status, 404);
});

test('static PWA assets are served with security headers', async () => {
  const res = await fetch(base + '/');
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
  const t = await fetch(base + '/../../etc/passwd'); assert.ok([200, 400].includes(t.status));
  const body = await (await fetch(base + '/%2e%2e/%2e%2e/etc/passwd')).text();
  assert.ok(!body.includes('root:'));
});
