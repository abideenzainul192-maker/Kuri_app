# Database

SQLite file `data/kuri.db` (WAL). The full DDL is in [schema.sql](schema.sql); it is applied automatically on start (`CREATE TABLE IF NOT EXISTS`).

| Table | Purpose |
|---|---|
| `settings` | Every configurable KURI setting (key → JSON value) |
| `admins`, `members` | Two administrator accounts (with permissions) and registered members (+ UPI details, WhatsApp opt-in) |
| `entries`, `entry_members` | A draw entry (individual or team) and its people with monthly share and prize % |
| `months` | Cycle: due date and draw date per month |
| `payments` | Submitted / verified / rejected payments (unique UTR among live payments) |
| `draws`, `prizes` | Immutable draw records (seed, eligible list + hash, rules, winners) and prize payout tracking |
| `reminders`, `reminder_messages` | Schedules and every message with its delivery status |
| `notifications` | In-app notifications |
| `audit_log` | Hash-chained, append-only log |
| `sessions`, `otps` | Hashed session tokens, hashed OTPs |
