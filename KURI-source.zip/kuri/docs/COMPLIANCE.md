# Legal and compliance — read before operating with real money

**This software does not make a scheme legal, licensed or compliant, and nothing in it or in this repository is legal advice.**
KURI only *records and calculates*; it does not hold money (members pay into the account you operate).

## Why this matters
A monthly pooled contribution with a periodic draw/prize closely resembles a **chit fund**. In India chit funds are regulated by the **Chit Funds Act, 1982** and **state rules** (Kerala has its own regulatory regime for *kuris*, administered through the Registrar of Chits and, for state-run chits, KSFE). Running an unregistered chit, accepting deposits from the public, or operating something that looks like a lottery or unauthorised collective investment scheme can attract serious civil and criminal liability — for the organiser and potentially for administrators.

## Questions to put to a qualified lawyer / chartered accountant **before launch**
1. Does this arrangement qualify as a chit under the Chit Funds Act and Kerala rules? Is registration, a licence, a foreman appointment, security deposit or prescribed agreement/forms required, and what commission and prize/discount rules apply?
2. Is a purely private, small, closed group (family/friends) exempt in your state, and under what limits?
3. Is the random draw/prize structure permissible, or does it fall under lotteries/gambling law?
4. Could receiving pooled funds be treated as accepting deposits (Banning of Unregulated Deposit Schemes Act, 2019, RBI rules)?
5. Tax: GST on foreman commission/services, TDS, income tax treatment of prizes and of the organiser's receipts.
6. Bank/UPI: the collection account type, KYC, and whether your bank permits pooled collections on that account.
7. Written agreement/terms for members; prize-sharing agreement for teams; dispute and default handling; record retention.
8. Data protection (DPDP Act 2023): consent, privacy notice, retention, breach handling.

## Third-party approvals
- **WhatsApp Business Platform (Meta):** business verification, message templates approved by Meta, proof of **opt-in** for every member, and compliance with WhatsApp Business/Commerce policies. Financial-reminder content must stay factual; do not send to non-opted-in people.
- **Payment gateway / UPI collection (if added):** merchant onboarding and KYC with the provider; the provider may refuse chit/pooled-collection business. Get written approval **before** building on it.
- **SMS (if used for OTP):** TRAI DLT registration of sender ID and templates.

## What the software does to help (not to replace the above)
Server-side validation, an immutable draw record, a tamper-evident audit log, explicit opt-in tracking, configurable rules shown to members, and exports for your accountant. Treat these as record-keeping aids only.
