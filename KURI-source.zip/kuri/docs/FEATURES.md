# Feature status

"Verified" = exercised by the automated tests (`npm test`) and/or by driving the real UI in a browser during development.

## Fully working (no external service needed)
| Area | Status |
|---|---|
| PWA: installable, service worker, mobile-first, English/Malayalam toggle, phone + desktop layouts | Working, UI-verified |
| Two administrator accounts, password login, forced password change, 12 configurable permissions, session expiry, rate limiting | Working, verified |
| Member management: add / edit / deactivate / search; registration details; only approved phones can log in | Working, verified |
| Member login with phone + OTP | Working. **OTP delivery needs WhatsApp or SMS** (see below) |
| Every important setting editable in-app: entries, contribution, duration, winners/draw, prize, due/draw day, first date, rules (EN+ML), privacy, team size | Working, verified; nothing hard-coded |
| Individual entries and teams of 2–4; per-member contribution and prize %; team = one draw entry; validation that shares add up | Working, verified |
| Payments: member submits UTR; admin verifies/rejects/reverses; admin records cash/bank/UPI; duplicate UTR blocked; balances update automatically; QR is never treated as proof | Working, verified |
| Member UPI ID + QR upload, admin approve/reject, QR visible only to that member and admins (audited) | Working, verified |
| Secure draw: server CSPRNG seed, HMAC ranking, whole entries only, exclusions (unpaid / already won / inactive), permanent append-only history, public seed + one-click verification, no admin override | Working, verified |
| Winners and prizes: privacy modes, team prize split by agreed %, exact-rupee rounding, payout status/date/reference | Working, verified |
| Reminder scheduler (runs on the server): per-entry, custom dates + intervals, start/end, 1y/2y/custom period, pause/resume/stop, auto-stop when fully paid, partial payments reduce the amount, message log with honest states | Working, verified (WhatsApp transport tested with a mock) |
| Dashboard, in-app notifications, announcements | Working |
| Reports (7) with on-screen view, **Excel** and **PDF** export | Working, verified |
| Audit log (hash-chained, tamper-evident, viewable + exportable) | Working, verified |
| Automatic daily backups, manual backup/download, restore script | Working (restore tested manually) |

## Needs an external account or your action before real use
| Item | What is needed |
|---|---|
| Delivering login OTPs | WhatsApp Authentication template **or** an SMS provider (DLT-registered in India) |
| Real WhatsApp reminders | Meta WhatsApp Business account, verified number, **approved templates**, token, webhook. Until configured, reminders are recorded as **failed** (never "sent") |
| Payment gateway checkout (Razorpay/Cashfree/etc.) | **Not implemented.** Needs a merchant account + KYC. Today payments are verified by an admin against the real bank/UPI statement |
| Push notifications to the phone | **Not implemented.** Notifications are in-app (and WhatsApp for reminders) |
| Off-site backups | You must copy `data/` elsewhere (see DEPLOY.md) |
| Hosting, domain, HTTPS | Your VPS/PaaS + domain |
| Legal registration / licence / review | **Not something software can provide** — see COMPLIANCE.md |

## Known limitations
- PDF export replaces Malayalam characters with `?` (no Malayalam font is bundled); Excel export keeps them.
- One server instance only (SQLite). Fine for tens/hundreds of members, not a multi-region system.
- Rate-limit counters are in memory and reset on restart.
- Uploaded QR images are stored on disk (not inside the DB backup).
- A real-world load test, a penetration test and testing on a real WhatsApp number have **not** been done.
