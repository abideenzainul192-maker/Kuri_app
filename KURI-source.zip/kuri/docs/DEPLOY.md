# Deployment

KURI is **one Node process + one data folder**. The data folder holds the SQLite database, uploaded QR images and backups, so it **must live on a persistent disk**. Do not run on platforms with an ephemeral filesystem unless you attach a volume. Run **one instance only** (SQLite is single-writer; the reminder scheduler assumes one process).

HTTPS is mandatory (cookies are `Secure`, PWA install and service worker need it). Set `KURI_TRUST_PROXY=1` behind a proxy.

## Option A — VPS (recommended for control; ~₹400–800/month, Mumbai region for latency)
```bash
# Ubuntu 24.04
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash - && sudo apt install -y nodejs python3-openpyxl python3-reportlab fonts-dejavu-core caddy
sudo useradd -r -m kuri && sudo -u kuri git clone <your repo> /opt/kuri
sudo mkdir -p /var/lib/kuri && sudo chown kuri /var/lib/kuri && sudo chmod 700 /var/lib/kuri
sudo cp /opt/kuri/.env.example /etc/kuri.env && sudo nano /etc/kuri.env     # fill in; chmod 600
```
`/etc/systemd/system/kuri.service`:
```ini
[Unit]
Description=KURI
After=network.target
[Service]
User=kuri
WorkingDirectory=/opt/kuri
EnvironmentFile=/etc/kuri.env
ExecStart=/usr/bin/node --disable-warning=ExperimentalWarning server.js
Restart=always
NoNewPrivileges=true
[Install]
WantedBy=multi-user.target
```
`/etc/caddy/Caddyfile` (automatic HTTPS):
```
kuri.example.com {
    reverse_proxy 127.0.0.1:3000
}
```
```bash
sudo systemctl enable --now kuri caddy && journalctl -u kuri -f     # initial admin passwords are printed here once
```

## Option B — Docker (Render, Railway, Fly.io, any host)
```bash
docker build -t kuri .
docker run -d --name kuri -p 3000:3000 -v kuri-data:/data --env-file .env kuri
```
On a PaaS: create a **Web Service** from the Dockerfile, attach a **persistent disk mounted at `/data`**, set the environment variables, keep instances = 1, add your domain.

## Backups and recovery
- The server writes a consistent snapshot daily to `<data>/backups/` (last 30 kept, `KURI_BACKUP_KEEP`). Admins can also take/download one in **Backups**.
- **Off-site copy is your responsibility** (same disk ≠ backup). Example nightly cron:
  `0 3 * * * rsync -a /var/lib/kuri/ backup-host:/kuri-backups/$(date +\%F)/` or sync to S3/Backblaze with `rclone`. Also enable your VPS provider's disk snapshots.
- Database backups do **not** include `data/uploads` (QR images) — the rsync above covers both.
- **Restore** (stop the app first):
  ```bash
  sudo systemctl stop kuri
  sudo -u kuri KURI_DATA_DIR=/var/lib/kuri npm --prefix /opt/kuri run restore -- /var/lib/kuri/backups/kuri-2026-11-22T03-00-00-auto.db
  sudo systemctl start kuri
  ```
  The current database is moved aside, never deleted. Test a restore on a spare machine **before** you need it.

## Updating
`git pull && sudo systemctl restart kuri`. The schema is created/extended on start; take a manual backup first.

## Go-live checklist
- [ ] HTTPS working; `KURI_DEV_OTP` **not** set
- [ ] Admin passwords changed; `INITIAL_ADMIN_CREDENTIALS.txt` deleted
- [ ] OTP delivery (WhatsApp/SMS) tested with a real phone
- [ ] WhatsApp templates approved; webhook verified; test reminder reaches *delivered*
- [ ] A backup restored successfully on another machine
- [ ] Legal review done — see COMPLIANCE.md
