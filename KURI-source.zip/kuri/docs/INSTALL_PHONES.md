# Installing KURI on phones and tablets

KURI is a PWA: open the web address, then add it to the home screen. No app store needed. It needs the site to be served over **HTTPS**.

## Android (Chrome)
1. Open `https://your-kuri-address` in **Chrome**.
2. Tap the **⋮** menu → **Install app** (or **Add to Home screen**). Or tap the **Install app** button on the Home / Profile page.
3. Open **KURI** from the home screen. It runs full-screen.

## iPhone / iPad (Safari — must be Safari)
1. Open the address in **Safari**.
2. Tap the **Share** button (square with arrow) → scroll → **Add to Home Screen** → **Add**.
3. Open **KURI** from the home screen.

## Desktop
Chrome/Edge: install icon in the address bar. Or just use the browser tab.

## Member quick guide (share this)
1. Sign in with the phone number the organiser registered → you get an OTP → enter it.
2. **Home** shows your entry, your share, what you have paid and what is left.
3. **Pay**: pay with any UPI app to the account shown, then enter the **transaction reference (UTR)** and submit. It counts as paid **only after the administrator verifies it**.
4. **Draws** shows every result; "Verify this draw" re-checks the result with the saved random seed.
5. **Profile**: choose Malayalam/English, WhatsApp reminders on/off, and upload your own UPI QR + UPI ID (used only for prize payment, after admin approval).
