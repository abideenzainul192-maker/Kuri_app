# Security design (and its honest limits)

## What is in place
- **Transport:** HTTPS required in production; `Secure; HttpOnly; SameSite=Strict` session cookie; HSTS; CSP (`script-src 'self'`, no inline scripts), `X-Frame-Options: DENY`, `nosniff`, no referrer.
- **Authentication:** admins — phone + password (scrypt, per-user salt, min 10 chars with letters+digits, forced change of the initial password, sessions revoked on password change/reset, 8-hour sessions, lock-out style rate limit). Members — phone + 6-digit OTP (5-minute expiry, one use, attempt limits, hashed in DB); unregistered numbers get an identical response (no account enumeration).
- **Authorisation:** server-side on every route. Role check + per-admin permission check. Members can only reach their own data: teammates are shown by name and agreed share only, never their payments or payment details. Deactivating a member/admin kills their sessions.
- **CSRF:** state-changing requests require a custom header; cookies are SameSite=Strict.
- **Input validation on the server** for every money field (whole rupees, bounds, ranges, duplicate UTR blocked with a unique index). Amounts, balances and eligibility are computed on the server from verified payments only; the client is never trusted.
- **Uploads:** QR images are type-sniffed (PNG/JPEG/WebP magic bytes), size-limited, stored with random names, mode 0600, served only through authenticated endpoints; admin views are audited.
- **Audit log:** every sensitive action (login, member/entry/settings changes, payment decisions, draws, prizes, reminders, backups, QR views, admin changes). Each row contains the hash of the previous row; tampering breaks the chain, which the Audit screen and the activity report check. Database triggers also refuse UPDATE/DELETE on the audit log and on draw history.
- **Draw integrity:** see below.
- **Webhook:** WhatsApp callbacks accepted only with a valid `X-Hub-Signature-256`.
- **Exports:** spreadsheet formula injection neutralised.

## Draw fairness — what is and is not guaranteed
The winner is a pure function of a 256-bit seed from the OS CSPRNG and the eligible list, both stored permanently with the result; `HMAC-SHA256(seed, "month:entryId")` ranks entries and the lowest scores win. There is **no API** to choose, re-roll, edit or delete a draw, and a drawn month cannot be redrawn. Members can click **Verify this draw** to recompute the result themselves.
Limit: this prevents manipulation *through the application*. A person with shell access to the server and the database file could in principle edit the file (dropping the triggers). Mitigations: do not share server access with the people running the kuri; keep the two admins separate from whoever operates the server; keep off-site backups and compare; the audit hash chain will show if rows were removed.

## Known limits — please read
- **No encryption at rest.** Use full-disk encryption on the server/volume; protect backups the same way.
- Phone numbers, addresses and UPI IDs are stored as plain text in SQLite.
- OTPs are short-lived and hashed with SHA-256; a leaked database within the 5-minute window could allow brute-forcing a code. Rate limits protect the live service.
- No two-factor for admins (a password only). Use long unique passwords; consider restricting the admin URL by IP at your proxy.
- In-memory rate limiting (per process, resets on restart).
- This has **not** had an independent penetration test.
- Under India's DPDP Act you are a data fiduciary for members' personal data: obtain consent, publish a privacy notice, honour deletion/correction requests, and report breaches. The software gives you the data controls; the obligations are yours.
