CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT
);

CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  pw_salt TEXT NOT NULL,
  pw_hash TEXT NOT NULL,
  permissions TEXT NOT NULL DEFAULT '[]',
  active INTEGER NOT NULL DEFAULT 1,
  must_change_pw INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS members (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  address TEXT,
  registration_details TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  language TEXT NOT NULL DEFAULT 'en',
  whatsapp_opt_in INTEGER NOT NULL DEFAULT 0,
  whatsapp_opt_in_at TEXT,
  whatsapp_opt_in_source TEXT,
  upi_id TEXT,
  upi_qr_file TEXT,
  upi_status TEXT NOT NULL DEFAULT 'none' CHECK (upi_status IN ('none','pending','approved','rejected')),
  upi_reviewed_by INTEGER,
  upi_reviewed_at TEXT,
  upi_note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS entries (
  id INTEGER PRIMARY KEY,
  label TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('individual','team')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS entry_members (
  id INTEGER PRIMARY KEY,
  entry_id INTEGER NOT NULL REFERENCES entries(id),
  member_id INTEGER NOT NULL REFERENCES members(id),
  monthly_share INTEGER NOT NULL CHECK (monthly_share > 0),
  prize_percent REAL NOT NULL CHECK (prize_percent > 0 AND prize_percent <= 100),
  UNIQUE (entry_id, member_id)
);

CREATE TABLE IF NOT EXISTS months (
  month_no INTEGER PRIMARY KEY,
  due_date TEXT NOT NULL,
  draw_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY,
  entry_id INTEGER NOT NULL REFERENCES entries(id),
  member_id INTEGER NOT NULL REFERENCES members(id),
  month_no INTEGER NOT NULL REFERENCES months(month_no),
  amount INTEGER NOT NULL CHECK (amount > 0),
  txn_ref TEXT,
  paid_on TEXT,
  method TEXT NOT NULL DEFAULT 'upi' CHECK (method IN ('upi','cash','bank','gateway')),
  status TEXT NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','verified','rejected')),
  submitted_by TEXT NOT NULL DEFAULT 'member',
  note TEXT,
  reviewed_by INTEGER,
  reviewed_at TEXT,
  reject_reason TEXT,
  created_at TEXT NOT NULL
);
-- A transaction reference can only back one live (non-rejected) payment.
CREATE UNIQUE INDEX IF NOT EXISTS ux_payments_txn ON payments (lower(txn_ref))
  WHERE txn_ref IS NOT NULL AND status != 'rejected';
CREATE INDEX IF NOT EXISTS ix_payments_member_month ON payments (member_id, month_no, status);

CREATE TABLE IF NOT EXISTS draws (
  id INTEGER PRIMARY KEY,
  month_no INTEGER NOT NULL UNIQUE,
  drawn_at TEXT NOT NULL,
  triggered_by TEXT NOT NULL,
  algorithm TEXT NOT NULL,
  seed TEXT NOT NULL,
  eligible TEXT NOT NULL,
  eligible_hash TEXT NOT NULL,
  rules TEXT NOT NULL,
  winners TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS prizes (
  id INTEGER PRIMARY KEY,
  draw_id INTEGER NOT NULL REFERENCES draws(id),
  entry_id INTEGER NOT NULL REFERENCES entries(id),
  month_no INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  shares TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid')),
  paid_date TEXT,
  payment_ref TEXT,
  note TEXT,
  UNIQUE (draw_id, entry_id)
);

CREATE TABLE IF NOT EXISTS reminders (
  id INTEGER PRIMARY KEY,
  entry_id INTEGER NOT NULL REFERENCES entries(id),
  month_no INTEGER,
  amount_hint INTEGER,
  due_date TEXT,
  start_date TEXT NOT NULL,
  end_date TEXT,
  interval_days INTEGER,
  custom_dates TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','stopped','completed')),
  stop_reason TEXT,
  next_run_at TEXT,
  last_run_at TEXT,
  created_by INTEGER,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reminder_messages (
  id INTEGER PRIMARY KEY,
  reminder_id INTEGER REFERENCES reminders(id),
  member_id INTEGER NOT NULL REFERENCES members(id),
  phone TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'reminder',
  template TEXT,
  body TEXT,
  amount INTEGER,
  status TEXT NOT NULL CHECK (status IN ('queued','accepted','sent','delivered','read','failed')),
  provider_message_id TEXT,
  error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_msg_provider ON reminder_messages (provider_message_id);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY,
  member_id INTEGER NOT NULL REFERENCES members(id),
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL,
  read_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_notif_member ON notifications (member_id, created_at);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY,
  at TEXT NOT NULL,
  actor_type TEXT NOT NULL,
  actor_id INTEGER,
  actor_name TEXT,
  action TEXT NOT NULL,
  target TEXT,
  detail TEXT,
  ip TEXT,
  prev_hash TEXT NOT NULL,
  hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  role TEXT NOT NULL CHECK (role IN ('admin','member')),
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  ip TEXT
);

CREATE TABLE IF NOT EXISTS otps (
  id INTEGER PRIMARY KEY,
  phone TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  used INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_otps_phone ON otps (phone, created_at);

-- Draw history and the audit log are append-only. Even with direct SQL access through the
-- application, rows cannot be changed or removed without dropping these triggers (which a
-- DB owner can still do; see docs/SECURITY.md for the honest limits).
CREATE TRIGGER IF NOT EXISTS draws_no_update BEFORE UPDATE ON draws
BEGIN SELECT RAISE(ABORT, 'draw history is immutable'); END;
CREATE TRIGGER IF NOT EXISTS draws_no_delete BEFORE DELETE ON draws
BEGIN SELECT RAISE(ABORT, 'draw history is immutable'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit log is append-only'); END;
