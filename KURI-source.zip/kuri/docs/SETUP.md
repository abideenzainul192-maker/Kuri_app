# Setup

## 1. Run locally
```bash
node -v                 # must be 22.5 or newer
cp .env.example .env    # then edit; or export the variables in your shell
npm start               # http://localhost:3000
```
`npm start` does not read `.env` by itself. Either `export $(grep -v '^#' .env | xargs)` first, use `node --env-file=.env server.js`, or set the variables in your host (Docker `--env-file`, Render/Railway dashboard).

On the **first start** two administrator accounts are created from `ADMIN1_*` / `ADMIN2_*`. Passwords are random unless `ADMIN_INITIAL_PASSWORD` is set; they are printed once and saved to `data/INITIAL_ADMIN_CREDENTIALS.txt` (delete that file after use). Both admins are forced to choose a new password at first login.

## 2. First-time configuration (as admin, in the app)
1. **Settings** → set entries, monthly contribution, duration, winners per draw, prize amount, due/draw day, **first due date**, rules (English + Malayalam), collection UPI ID. Defaults: 20 × ₹20,000 = ₹4,00,000/month.
2. **Settings → Generate cycle** → creates each month's due and draw dates (editable individually).
3. **Members** → add members (their phone numbers become their login). Tick WhatsApp opt-in only if they actually agreed.
4. **Entries** → add individual entries, or teams of 2–4 with each person's contribution (must add up to the entry amount) and prize % (must total 100).
5. **Admins** → adjust what each administrator may do.

## 3. Member login OTP
OTPs are 6 digits, valid 5 minutes, rate-limited. In production they must be **delivered**:
- Set `WHATSAPP_OTP_TEMPLATE` to an approved WhatsApp *Authentication* template (below), **or**
- extend `sendOtp()` in `lib/whatsapp.js` for an SMS provider (MSG91, Twilio, etc. — DLT registration is required for SMS in India).

Without a provider the OTP is only written to the server log. `KURI_DEV_OTP=1` returns it in the API response — **preview only, never in production**.

## 4. WhatsApp Business Platform (reminders)
You need a Meta Business account, a WhatsApp Business number, and a permanent access token.
1. In Meta for Developers create an app → add **WhatsApp** → note the **Phone number ID** and create a **System User permanent token**.
2. Create and get approved these **templates** (category *Utility*), body variables `{{1}}` name, `{{2}}` amount, `{{3}}` month number, `{{4}}` due date:
   - `kuri_payment_reminder_en` — "Hello {{1}}, your KURI contribution of ₹{{2}} for month {{3}} is pending. Due date: {{4}}. If you have already paid, please ignore this message."
   - `kuri_payment_reminder_ml` — the same text in Malayalam
3. Set `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_ID`, `WHATSAPP_VERIFY_TOKEN`, `WHATSAPP_APP_SECRET`.
4. Webhook: callback URL `https://YOUR-DOMAIN/webhooks/whatsapp`, verify token = `WHATSAPP_VERIFY_TOKEN`, subscribe to **messages**. This is what turns "accepted" into "sent / delivered / read / failed".

Delivery states are honest: `queued` → `accepted` (Meta took it) → `sent/delivered/read` (only from Meta's webhook) or `failed` (with reason). Members who have not opted in, or a missing configuration, produce `failed`, never a fake "sent".

## 5. Gateway payments
Payments today = member submits UTR → admin verifies against the real bank/UPI statement (or admin records cash/bank). A payment gateway (Razorpay/Cashfree) needs your merchant account and KYC; the `gateway` payment method and server-side verification path exist, the checkout + webhook must be added with your credentials.
