'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { openDb, getSettings, DATA_DIR } = require('./lib/db');
const C = require('./lib/core');
const S = require('./lib/services');
const D = require('./lib/draw');
const R = require('./lib/reminders');
const RP = require('./lib/reports');
const B = require('./lib/backup');
const WA = require('./lib/whatsapp');
const { HttpError, bad, forbidden, notFound, audit } = C;

const PUBLIC_DIR = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

// ------------------------------------------------------------------------------------
// Admin bootstrap: exactly two administrator accounts
// ------------------------------------------------------------------------------------
function bootstrapAdmins(db) {
  if (db.prepare('SELECT COUNT(*) c FROM admins').get().c > 0) return null;
  const defs = [
    { name: process.env.ADMIN1_NAME || 'Admin One', phone: C.normPhone(process.env.ADMIN1_PHONE || '+910000000001') },
    { name: process.env.ADMIN2_NAME || 'Admin Two', phone: C.normPhone(process.env.ADMIN2_PHONE || '+910000000002') },
  ];
  const lines = ['KURI initial administrator credentials (shown once - change the passwords at first login, then delete this file)', ''];
  for (const d of defs) {
    const pw = process.env.ADMIN_INITIAL_PASSWORD || crypto.randomBytes(9).toString('base64url');
    const { salt, hash } = C.hashPassword(pw);
    db.prepare('INSERT INTO admins (name, phone, pw_salt, pw_hash, permissions, active, must_change_pw, created_at) VALUES (?,?,?,?,?,1,1,?)')
      .run(d.name, d.phone, salt, hash, JSON.stringify(C.ALL_PERMISSIONS), C.nowIso());
    lines.push(`${d.name}: phone ${d.phone}  password ${pw}`);
  }
  audit(db, null, 'admins.bootstrap', null, 'Two administrator accounts created');
  const file = path.join(process.env.KURI_DATA_DIR || DATA_DIR, 'INITIAL_ADMIN_CREDENTIALS.txt');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, lines.join('\n') + '\n', { mode: 0o600 });
  return { file, lines };
}

// ------------------------------------------------------------------------------------
// Router
// ------------------------------------------------------------------------------------
const routes = [];
function route(method, pattern, opts, handler) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, opts: opts || {}, handler });
}
const M = (db, ctx) => ({ type: 'member', id: ctx.session.user.id, name: ctx.session.user.name });
const A = (ctx) => ({ type: 'admin', id: ctx.session.user.id, name: ctx.session.user.name });
const id = (ctx, k = 'id') => { const n = Number(ctx.params[k]); if (!Number.isInteger(n)) throw bad('Invalid id'); return n; };

function defineRoutes(db) {
  // ---------- public ----------
  route('GET', '/api/health', {}, () => ({ ok: true, time: C.nowIso() }));

  route('POST', '/api/auth/otp/request', {}, async (ctx) => {
    const phone = C.normPhone(ctx.body.phone);
    if (!phone) throw bad('Enter a valid phone number');
    if (!C.rateLimit('otp-ip:' + ctx.ip, 60, 3600e3) || !C.rateLimit('otp-phone:' + phone, 5, 3600e3)) throw new HttpError(429, 'Too many OTP requests. Try again later.');
    const m = db.prepare("SELECT * FROM members WHERE phone = ? AND status = 'active'").get(phone);
    const resp = { ok: true, message: 'If this number is registered, an OTP has been sent.' };
    if (!m) { audit(db, null, 'otp.unregistered_attempt', null, { phone_tail: phone.slice(-4) }, ctx.ip); return resp; }
    const code = C.issueOtp(db, phone);
    const sent = await WA.sendOtp(phone, code, m.language);
    if (!sent.ok) throw new HttpError(502, 'Could not deliver the OTP. Please try again or contact the administrator.');
    if (process.env.KURI_DEV_OTP === '1') resp.dev_otp = code; // preview/testing ONLY - never enable in production
    return resp;
  });
  route('POST', '/api/auth/otp/verify', {}, (ctx) => {
    const phone = C.normPhone(ctx.body.phone);
    if (!phone || !/^\d{6}$/.test(String(ctx.body.code))) throw bad('Enter the 6-digit OTP');
    if (!C.rateLimit('otpv:' + phone, 10, 900e3)) throw new HttpError(429, 'Too many attempts. Try again later.');
    const m = db.prepare("SELECT * FROM members WHERE phone = ? AND status = 'active'").get(phone);
    if (!m || !C.verifyOtp(db, phone, String(ctx.body.code))) throw new HttpError(401, 'Invalid or expired OTP');
    const s = C.createSession(db, 'member', m.id, ctx.ip);
    audit(db, { type: 'member', id: m.id, name: m.name }, 'login.member', null, null, ctx.ip);
    return { cookie: s, body: { ok: true, role: 'member' } };
  });
  route('POST', '/api/auth/admin/login', {}, (ctx) => {
    const phone = C.normPhone(ctx.body.phone);
    const key = 'adm:' + (phone || 'x') + ':' + ctx.ip;
    if (!C.rateLimit(key, 6, 900e3)) throw new HttpError(429, 'Too many attempts. Try again in 15 minutes.');
    const a = phone && db.prepare('SELECT * FROM admins WHERE phone = ? AND active = 1').get(phone);
    const ok = a && typeof ctx.body.password === 'string' && C.checkPassword(ctx.body.password, a.pw_salt, a.pw_hash);
    if (!ok) { audit(db, null, 'login.admin_failed', null, { phone_tail: (phone || '').slice(-4) }, ctx.ip); throw new HttpError(401, 'Incorrect phone number or password'); }
    C.clearRate(key);
    const s = C.createSession(db, 'admin', a.id, ctx.ip);
    audit(db, { type: 'admin', id: a.id, name: a.name }, 'login.admin', null, null, ctx.ip);
    return { cookie: s, body: { ok: true, role: 'admin', must_change_pw: !!a.must_change_pw } };
  });
  route('POST', '/api/auth/logout', {}, (ctx) => { C.destroySession(db, ctx.token); return { clearCookie: true, body: { ok: true } }; });
  route('GET', '/api/auth/me', {}, (ctx) => {
    if (!ctx.session) return { role: null };
    const u = ctx.session.user;
    if (ctx.session.role === 'admin') return { role: 'admin', name: u.name, phone: u.phone, permissions: u.permissions, must_change_pw: !!u.must_change_pw };
    return { role: 'member', name: u.name, language: u.language };
  });
  route('POST', '/api/auth/admin/change-password', { auth: 'admin', allowPwChange: true }, (ctx) => {
    const a = ctx.session.user;
    if (!C.checkPassword(String(ctx.body.current || ''), a.pw_salt, a.pw_hash)) throw new HttpError(401, 'Current password is incorrect');
    if (!C.strongPassword(ctx.body.new)) throw bad('New password must be at least 10 characters and include letters and numbers');
    const { salt, hash } = C.hashPassword(ctx.body.new);
    db.prepare('UPDATE admins SET pw_salt=?, pw_hash=?, must_change_pw=0 WHERE id=?').run(salt, hash, a.id);
    db.prepare('DELETE FROM sessions WHERE role=? AND user_id=? AND token_hash != ?').run('admin', a.id, ctx.session.token_hash);
    audit(db, A(ctx), 'admin.password_change', `admin:${a.id}`, null, ctx.ip);
    return { ok: true };
  });

  // ---------- WhatsApp webhook ----------
  route('GET', '/webhooks/whatsapp', { raw: true }, (ctx) => {
    const { verifyToken } = WA.cfg();
    if (verifyToken && ctx.query['hub.mode'] === 'subscribe' && ctx.query['hub.verify_token'] === verifyToken) return { text: ctx.query['hub.challenge'] || '' };
    throw forbidden('Verification failed');
  });
  route('POST', '/webhooks/whatsapp', { raw: true, noCsrf: true }, (ctx) => {
    if (!WA.verifySignature(ctx.rawBody, ctx.req.headers['x-hub-signature-256'])) throw new HttpError(401, 'Bad signature');
    let body; try { body = JSON.parse(ctx.rawBody.toString()); } catch { throw bad('Invalid JSON'); }
    const n = R.applyWebhookStatuses(db, WA.parseStatuses(body));
    return { ok: true, updated: n };
  });

  // ---------- member ----------
  route('GET', '/api/me/overview', { auth: 'member' }, (ctx) => S.memberOverview(db, ctx.session.user));
  route('POST', '/api/me/payments', { auth: 'member' }, (ctx) => {
    if (!C.rateLimit('pay:' + ctx.session.user.id, 30, 3600e3)) throw new HttpError(429, 'Too many submissions');
    return S.submitPayment(db, ctx.session.user, ctx.body, ctx.ip);
  });
  route('POST', '/api/me/upi', { auth: 'member', bigBody: true }, (ctx) => S.saveUpi(db, ctx.session.user, ctx.body, ctx.ip));
  route('GET', '/api/me/upi/qr', { auth: 'member' }, (ctx) => {
    const q = S.readQr(ctx.session.user.id, db);
    if (!q) throw notFound('No QR uploaded');
    return { raw: q.data, type: q.type, headers: { 'Cache-Control': 'private, no-store' } };
  });
  route('PATCH', '/api/me/profile', { auth: 'member' }, (ctx) => {
    const m = ctx.session.user, b = ctx.body;
    if (b.language !== undefined) {
      if (!['en', 'ml'].includes(b.language)) throw bad('Invalid language');
      db.prepare('UPDATE members SET language = ? WHERE id = ?').run(b.language, m.id);
    }
    if (b.whatsapp_opt_in !== undefined) {
      const v = b.whatsapp_opt_in ? 1 : 0;
      db.prepare('UPDATE members SET whatsapp_opt_in = ?, whatsapp_opt_in_at = ?, whatsapp_opt_in_source = ? WHERE id = ?').run(v, v ? C.nowIso() : null, v ? 'member' : null, m.id);
      audit(db, M(db, ctx), v ? 'whatsapp.opt_in' : 'whatsapp.opt_out', `member:${m.id}`, null, ctx.ip);
    }
    return S.publicMember(S.getMember(db, m.id));
  });
  route('GET', '/api/me/notifications', { auth: 'member' }, (ctx) => db.prepare('SELECT * FROM notifications WHERE member_id = ? ORDER BY id DESC LIMIT 100').all(ctx.session.user.id));
  route('POST', '/api/me/notifications/read', { auth: 'member' }, (ctx) => { db.prepare('UPDATE notifications SET read_at = ? WHERE member_id = ? AND read_at IS NULL').run(C.nowIso(), ctx.session.user.id); return { ok: true }; });
  route('GET', '/api/draws', { auth: 'member' }, (ctx) => D.listDraws(db, { viewer: ctx.session.user.id }));
  route('GET', '/api/draws/:id/verify', { auth: 'member' }, (ctx) => D.publicVerification(db, id(ctx)));

  // ---------- admin ----------
  const adm = (perm) => ({ auth: 'admin', perm });
  route('GET', '/api/admin/dashboard', adm(), () => S.dashboard(db));
  route('GET', '/api/admin/settings', adm(), () => getSettings(db));
  route('PUT', '/api/admin/settings', adm('settings'), (ctx) => S.updateSettings(db, A(ctx), ctx.body, ctx.ip));

  route('GET', '/api/admin/members', adm('members'), () => S.listMembers(db));
  route('POST', '/api/admin/members', adm('members'), (ctx) => S.publicMember(S.addMember(db, A(ctx), ctx.body, ctx.ip)));
  route('PATCH', '/api/admin/members/:id', adm('members'), (ctx) => S.publicMember(S.updateMember(db, A(ctx), id(ctx), ctx.body, ctx.ip)));
  route('POST', '/api/admin/members/:id/status', adm('members'), (ctx) => S.publicMember(S.setMemberStatus(db, A(ctx), id(ctx), ctx.body.status, ctx.ip)));
  route('GET', '/api/admin/members/:id/qr', adm('payments'), (ctx) => {
    const q = S.readQr(id(ctx), db);
    if (!q) throw notFound('No QR uploaded');
    audit(db, A(ctx), 'upi.qr_view', `member:${id(ctx)}`, null, ctx.ip);
    return { raw: q.data, type: q.type, headers: { 'Cache-Control': 'private, no-store' } };
  });
  route('POST', '/api/admin/members/:id/upi-review', adm('payments'), (ctx) => S.reviewUpi(db, ctx.session.user, id(ctx), !!ctx.body.approve, ctx.body.note, ctx.ip));

  route('GET', '/api/admin/entries', adm('entries'), () => S.listEntries(db));
  route('POST', '/api/admin/entries', adm('entries'), (ctx) => S.createEntry(db, A(ctx), ctx.body, ctx.ip));
  route('PATCH', '/api/admin/entries/:id', adm('entries'), (ctx) => S.updateEntry(db, A(ctx), id(ctx), ctx.body, ctx.ip));

  route('GET', '/api/admin/months', adm(), () => S.listMonths(db));
  route('POST', '/api/admin/cycle/generate', adm('settings'), (ctx) => S.generateCycle(db, A(ctx), ctx.ip));
  route('PATCH', '/api/admin/months/:id', adm('settings'), (ctx) => S.updateMonth(db, A(ctx), id(ctx), ctx.body, ctx.ip));

  route('GET', '/api/admin/payments', adm('payments'), (ctx) => S.listPayments(db, ctx.query));
  route('POST', '/api/admin/payments/record', adm('payments'), (ctx) => S.recordPayment(db, ctx.session.user, ctx.body, ctx.ip));
  route('POST', '/api/admin/payments/:id/verify', adm('payments'), (ctx) => S.verifyPayment(db, ctx.session.user, id(ctx), ctx.ip));
  route('POST', '/api/admin/payments/:id/reject', adm('payments'), (ctx) => S.rejectPayment(db, ctx.session.user, id(ctx), ctx.body.reason, ctx.ip));

  route('GET', '/api/admin/draws', adm('draw'), (ctx) => D.listDraws(db, { admin: true, viewer: null }));
  route('GET', '/api/admin/draw/eligibility', adm('draw'), (ctx) => D.eligibility(db, Number(ctx.query.month_no)));
  route('POST', '/api/admin/draw/run', adm('draw'), (ctx) => D.runDraw(db, Number(ctx.body.month_no), { label: `admin:${ctx.session.user.id}`, actor: A(ctx) }, ctx.ip));
  route('GET', '/api/admin/draws/:id/verify', adm('draw'), (ctx) => D.publicVerification(db, id(ctx)));

  route('GET', '/api/admin/prizes', adm('prizes'), () => D.listPrizes(db));
  route('POST', '/api/admin/prizes/:id/paid', adm('prizes'), (ctx) => D.markPrizePaid(db, ctx.session.user, id(ctx), ctx.body, ctx.ip));

  route('GET', '/api/admin/reminders', adm('reminders'), () => ({ reminders: R.listReminders(db), whatsapp_configured: WA.isConfigured() }));
  route('POST', '/api/admin/reminders', adm('reminders'), (ctx) => R.createReminder(db, ctx.session.user, ctx.body, ctx.ip));
  route('POST', '/api/admin/reminders/:id/action', adm('reminders'), (ctx) => R.setReminderStatus(db, ctx.session.user, id(ctx), ctx.body.action, ctx.ip));
  route('GET', '/api/admin/messages', adm('reminders'), (ctx) => R.listMessages(db, ctx.query));
  route('POST', '/api/admin/reminders/run-now', adm('reminders'), async (ctx) => { await R.deliverQueued(db); return { ok: true }; });

  route('POST', '/api/admin/announce', adm('announce'), (ctx) => S.announce(db, ctx.session.user, ctx.body, ctx.ip));

  route('GET', '/api/admin/reports/:name', { auth: 'admin' }, async (ctx) => {
    const name = ctx.params.name;
    const perm = RP.PERMISSION[name] || 'reports';
    if (!ctx.session.user.permissions.includes(perm)) throw forbidden('You do not have permission for this report');
    const rep = RP.build(db, name, ctx.query);
    const fmt = ctx.query.format || 'json';
    if (fmt === 'json') return rep;
    if (!['xlsx', 'pdf'].includes(fmt)) throw bad('format must be json, xlsx or pdf');
    const buf = await RP.exportReport(rep, fmt);
    audit(db, A(ctx), 'report.export', name, { format: fmt }, ctx.ip);
    return { raw: buf, type: fmt === 'pdf' ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', headers: { 'Content-Disposition': `attachment; filename="kuri-${name}.${fmt}"` } };
  });

  route('GET', '/api/admin/audit', adm('audit'), (ctx) => ({
    chain: C.verifyAuditChain(db),
    rows: db.prepare('SELECT id, at, actor_type, actor_name, action, target, detail, ip FROM audit_log ORDER BY id DESC LIMIT ?').all(Math.min(Number(ctx.query.limit) || 200, 1000)),
  }));

  route('GET', '/api/admin/backups', adm('backups'), () => B.listBackups());
  route('POST', '/api/admin/backups', adm('backups'), (ctx) => { const r = B.createBackup(db, 'manual'); audit(db, A(ctx), 'backup.create', r.name, null, ctx.ip); return r; });
  route('GET', '/api/admin/backups/:name', adm('backups'), (ctx) => {
    const f = B.backupPath(ctx.params.name);
    if (!f) throw notFound('Backup not found');
    audit(db, A(ctx), 'backup.download', ctx.params.name, null, ctx.ip);
    return { raw: fs.readFileSync(f), type: 'application/octet-stream', headers: { 'Content-Disposition': `attachment; filename="${ctx.params.name}"` } };
  });

  route('GET', '/api/admin/admins', adm('manage_admins'), () => db.prepare('SELECT id, name, phone, permissions, active, must_change_pw FROM admins').all().map((a) => ({ ...a, permissions: JSON.parse(a.permissions) })));
  route('PATCH', '/api/admin/admins/:id', adm('manage_admins'), (ctx) => {
    const aid = id(ctx), b = ctx.body;
    const target = db.prepare('SELECT * FROM admins WHERE id = ?').get(aid);
    if (!target) throw notFound('Admin not found');
    if (b.permissions) {
      if (!Array.isArray(b.permissions) || !b.permissions.every((p) => C.ALL_PERMISSIONS.includes(p))) throw bad('Invalid permissions');
      if (aid === ctx.session.user.id && !b.permissions.includes('manage_admins')) throw bad('You cannot remove your own admin-management permission');
      db.prepare('UPDATE admins SET permissions = ? WHERE id = ?').run(JSON.stringify(b.permissions), aid);
    }
    if (b.name) db.prepare('UPDATE admins SET name = ? WHERE id = ?').run(String(b.name).slice(0, 80), aid);
    if (b.phone) {
      const p = C.normPhone(b.phone); if (!p) throw bad('Invalid phone');
      if (db.prepare('SELECT 1 FROM admins WHERE phone = ? AND id != ?').get(p, aid)) throw bad('Phone already used by another admin');
      db.prepare('UPDATE admins SET phone = ? WHERE id = ?').run(p, aid);
    }
    if (b.active !== undefined) {
      if (aid === ctx.session.user.id && !b.active) throw bad('You cannot deactivate yourself');
      db.prepare('UPDATE admins SET active = ? WHERE id = ?').run(b.active ? 1 : 0, aid);
      if (!b.active) C.destroyUserSessions(db, 'admin', aid);
    }
    audit(db, A(ctx), 'admin.update', `admin:${aid}`, { fields: Object.keys(b) }, ctx.ip);
    const a = db.prepare('SELECT id, name, phone, permissions, active FROM admins WHERE id = ?').get(aid);
    return { ...a, permissions: JSON.parse(a.permissions) };
  });
  route('POST', '/api/admin/admins/:id/reset-password', adm('manage_admins'), (ctx) => {
    const aid = id(ctx);
    if (aid === ctx.session.user.id) throw bad('Use Change password for your own account');
    if (!db.prepare('SELECT 1 FROM admins WHERE id = ?').get(aid)) throw notFound('Admin not found');
    const temp = crypto.randomBytes(9).toString('base64url');
    const { salt, hash } = C.hashPassword(temp);
    db.prepare('UPDATE admins SET pw_salt=?, pw_hash=?, must_change_pw=1 WHERE id=?').run(salt, hash, aid);
    C.destroyUserSessions(db, 'admin', aid);
    audit(db, A(ctx), 'admin.password_reset', `admin:${aid}`, null, ctx.ip);
    return { temporary_password: temp, note: 'Shown once. The admin must change it at next login.' };
  });
}

// ------------------------------------------------------------------------------------
// HTTP plumbing
// ------------------------------------------------------------------------------------
function parseCookies(h) {
  const out = {};
  for (const p of (h || '').split(';')) { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); }
  return out;
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let n = 0;
    req.on('data', (c) => { n += c.length; if (n > limit) { reject(new HttpError(413, 'Request too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function createServer(db) {
  defineRoutes(db);
  const trustProxy = process.env.KURI_TRUST_PROXY === '1';

  const baseHeaders = (req) => {
    const h = {
      'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
      'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
    };
    if (req.headers['x-forwarded-proto'] === 'https' || req.socket.encrypted) h['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
    return h;
  };

  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    const ip = (trustProxy && req.headers['x-forwarded-for']?.split(',')[0].trim()) || req.socket.remoteAddress;
    const headers = baseHeaders(req);
    const send = (status, body, extra = {}) => { res.writeHead(status, { ...headers, ...extra }); res.end(body); };
    const json = (status, obj, extra) => send(status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra });

    try {
      // ---- API & webhooks ----
      if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/webhooks/')) {
        const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
        if (!r) return json(404, { error: 'Not found' });
        const m = url.pathname.match(r.re);
        const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
        const token = parseCookies(req.headers.cookie).kuri_session;
        const session = C.loadSession(db, token);

        if (!['GET', 'HEAD'].includes(req.method) && !r.opts.noCsrf && req.headers['x-requested-with'] !== 'kuri') throw forbidden('Missing request header');
        if (r.opts.auth) {
          if (!session || session.role !== r.opts.auth) throw new HttpError(401, 'Please sign in', 'auth');
          if (session.role === 'admin') {
            if (session.user.must_change_pw && !r.opts.allowPwChange) throw new HttpError(403, 'You must change your password first', 'password_change_required');
            if (r.opts.perm && !session.user.permissions.includes(r.opts.perm)) throw forbidden('You do not have permission for this action');
          }
        }
        let rawBody = null, body = {};
        if (!['GET', 'HEAD'].includes(req.method)) {
          rawBody = await readBody(req, r.opts.bigBody ? 3 * 1024 * 1024 : 256 * 1024);
          if (!r.opts.raw && rawBody.length) {
            try { body = JSON.parse(rawBody.toString('utf8')); } catch { throw bad('Request body must be JSON'); }
            if (body === null || typeof body !== 'object' || Array.isArray(body)) throw bad('Request body must be a JSON object');
          }
        }
        const query = Object.fromEntries(url.searchParams);
        const out = await r.handler({ db, req, params, query, body, rawBody, session, token, ip });
        if (out && out.raw) return send(200, out.raw, { 'Content-Type': out.type, 'Cache-Control': 'no-store', ...(out.headers || {}) });
        if (out && out.text !== undefined) return send(200, out.text, { 'Content-Type': 'text/plain' });
        if (out && out.cookie) {
          const secure = req.headers['x-forwarded-proto'] === 'https' || req.socket.encrypted ? '; Secure' : '';
          return json(200, out.body, { 'Set-Cookie': `kuri_session=${out.cookie.token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${out.cookie.maxAge}${secure}` });
        }
        if (out && out.clearCookie) return json(200, out.body, { 'Set-Cookie': 'kuri_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
        return json(200, out ?? { ok: true });
      }

      // ---- static PWA ----
      if (!['GET', 'HEAD'].includes(req.method)) return json(405, { error: 'Method not allowed' });
      let rel = decodeURIComponent(url.pathname);
      if (rel === '/') rel = '/index.html';
      let file = path.normalize(path.join(PUBLIC_DIR, rel));
      if (!file.startsWith(PUBLIC_DIR + path.sep)) return json(400, { error: 'Bad path' });
      if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(PUBLIC_DIR, 'index.html'); // SPA fallback
      const ext = path.extname(file);
      const cache = file.endsWith('sw.js') || file.endsWith('index.html') ? 'no-cache' : 'public, max-age=3600';
      return send(200, fs.readFileSync(file), { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': cache });
    } catch (e) {
      if (e instanceof HttpError) return json(e.status, { error: e.message, code: e.code });
      console.error('[error]', req.method, req.url, e);
      return json(500, { error: 'Something went wrong. Please try again.' });
    }
  });
}

// ------------------------------------------------------------------------------------
// Background scheduler: reminders, auto-draw, backups, housekeeping
// ------------------------------------------------------------------------------------
function startScheduler(db, intervalMs = 60000) {
  const run = async () => {
    try {
      await R.tick(db);
      const s = getSettings(db);
      const today = C.todayLocal();
      if (s.auto_draw) {
        for (const mo of db.prepare('SELECT * FROM months WHERE draw_date <= ? ORDER BY month_no').all(today)) {
          if (db.prepare('SELECT 1 FROM draws WHERE month_no = ?').get(mo.month_no)) continue;
          try { D.runDraw(db, mo.month_no, { label: 'auto-scheduler', actor: null }, null); console.log(`[draw] month ${mo.month_no} drawn automatically`); }
          catch (e) { console.error('[draw] auto draw failed:', e.message); }
          break; // one month per tick keeps ordering strict
        }
      }
      if (!B.hasBackupToday(today)) { const b = B.createBackup(db, 'auto'); audit(db, null, 'backup.auto', b.name); console.log('[backup] created', b.name); }
      db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(C.nowIso());
      db.prepare('DELETE FROM otps WHERE created_at < ?').run(new Date(Date.now() - 864e5).toISOString());
    } catch (e) { console.error('[scheduler]', e); }
  };
  const t = setInterval(run, intervalMs);
  t.unref?.();
  setTimeout(run, 2000).unref?.();
  return { stop: () => clearInterval(t), runOnce: run };
}

if (require.main === module) {
  const db = openDb();
  const boot = bootstrapAdmins(db);
  const port = parseInt(process.env.PORT || '3000', 10);
  createServer(db).listen(port, process.env.HOST || '0.0.0.0', () => {
    console.log(`KURI running on http://localhost:${port}`);
    if (boot) { console.log('\n' + boot.lines.join('\n') + `\n(also saved to ${boot.file})\n`); }
    if (!WA.isConfigured()) console.log('[warn] WhatsApp not configured: reminders will be recorded as FAILED, not sent. See docs/SETUP.md.');
    if (process.env.KURI_DEV_OTP === '1') console.log('[warn] KURI_DEV_OTP=1: OTPs are returned in API responses. Preview only - NEVER use with real members.');
  });
  startScheduler(db);
}

module.exports = { createServer, startScheduler, bootstrapAdmins };
