/* KURI front-end core: escaping templates, API client, i18n, layout, router. No framework, no build step. */
(function () {
  const K = (window.K = { views: {}, actions: {}, submits: {}, state: { auth: null, lang: 'en', cache: {} } });

  // ---------- safe HTML templating: every interpolated value is escaped unless wrapped in raw() ----------
  class Raw { constructor(s) { this.s = s; } toString() { return this.s; } }
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const val = (v) => (v instanceof Raw ? v.s : Array.isArray(v) ? v.map(val).join('') : v === false || v == null ? '' : esc(v));
  K.raw = (s) => new Raw(s);
  K.html = (strings, ...vals) => new Raw(strings.reduce((o, s, i) => o + s + (i < vals.length ? val(vals[i]) : ''), ''));
  K.esc = esc;
  const html = K.html;

  // ---------- i18n ----------
  K.t = (key, vars) => {
    let s = (I18N[K.state.lang] && I18N[K.state.lang][key]) ?? I18N.en[key] ?? key;
    if (vars) for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, v);
    return s;
  };
  const t = K.t;
  K.setLang = (l) => { K.state.lang = l; try { localStorage.setItem('kuri_lang', l); } catch (_) {} document.documentElement.lang = l; };
  try { K.setLang(localStorage.getItem('kuri_lang') || 'en'); } catch (_) {}

  // ---------- formatting ----------
  K.inr = (n) => '₹' + Number(n || 0).toLocaleString('en-IN');
  K.fdate = (d) => {
    if (!d) return '';
    const dt = new Date(/^\d{4}-\d{2}-\d{2}$/.test(d) ? d + 'T00:00:00' : d);
    return isNaN(dt) ? d : dt.toLocaleDateString(K.state.lang === 'ml' ? 'ml-IN' : 'en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  };
  K.fdt = (d) => (d ? new Date(d).toLocaleString(K.state.lang === 'ml' ? 'ml-IN' : 'en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');
  K.chip = (status, label) => html`<span class="chip ${status}">${label ?? status}</span>`;
  K.statusLabel = (s) => t('st_' + s);

  // ---------- API ----------
  K.api = async (method, url, body) => {
    let res;
    try {
      res = await fetch(url, { method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'kuri' }, body: body === undefined ? undefined : JSON.stringify(body) });
    } catch (e) { throw new Error('No connection. Check your internet and try again.'); }
    const ct = res.headers.get('content-type') || '';
    const data = ct.includes('json') ? await res.json() : null;
    if (!res.ok) {
      if (res.status === 401 && data?.code === 'auth') { K.state.auth = null; K.render(); }
      if (res.status === 403 && data?.code === 'password_change_required' && K.state.auth) { K.state.auth.must_change_pw = true; K.render(); }
      const e = new Error(data?.error || t('err_generic')); e.status = res.status; throw e;
    }
    return data;
  };
  K.get = (u) => K.api('GET', u);
  K.post = (u, b) => K.api('POST', u, b ?? {});

  // ---------- toast / modal ----------
  let toastTimer;
  K.toast = (msg, bad) => {
    const el = document.getElementById('toast');
    el.textContent = msg; el.className = 'show' + (bad ? ' bad' : '');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => (el.className = ''), 3200);
  };
  K.modal = (content) => {
    const root = document.getElementById('modal-root');
    root.innerHTML = `<div class="modal-bg" data-act="modal-bg"><div class="modal" role="dialog" aria-modal="true">${content.s ?? content}</div></div>`;
    const first = root.querySelector('input,select,textarea,button'); if (first) first.focus();
  };
  K.closeModal = () => { document.getElementById('modal-root').innerHTML = ''; };
  K.confirm = (title, message, okLabel) => new Promise((resolve) => {
    K.modal(html`<h2>${title}</h2><p>${message}</p><div class="sticky-actions"><button class="sec" data-act="confirm-no">${t('cancel')}</button><button data-act="confirm-yes">${okLabel || 'OK'}</button></div>`);
    K._confirm = resolve;
  });
  K.prompt = (title, label, okLabel) => new Promise((resolve) => {
    K.modal(html`<h2>${title}</h2><label>${label}</label><input id="prompt-input" maxlength="300"><div class="sticky-actions"><button class="sec" data-act="prompt-no">${t('cancel')}</button><button data-act="prompt-yes">${okLabel || 'OK'}</button></div>`);
    K._prompt = resolve;
  });

  // ---------- form helpers ----------
  K.formData = (form) => {
    const o = {};
    for (const el of form.elements) {
      if (!el.name) continue;
      if (el.type === 'checkbox') o[el.name] = el.checked;
      else if (el.type === 'radio') { if (el.checked) o[el.name] = el.value; }
      else if (el.type === 'number') o[el.name] = el.value === '' ? null : Number(el.value);
      else o[el.name] = el.value === '' ? null : el.value;
    }
    return o;
  };
  K.field = (label, name, opts = {}) => html`<label for="f-${name}">${label}</label>
    <input id="f-${name}" name="${name}" type="${opts.type || 'text'}" value="${opts.value ?? ''}" ${opts.required ? K.raw('required') : ''} ${opts.attrs ? K.raw(opts.attrs) : ''} ${opts.placeholder ? K.raw(`placeholder="${esc(opts.placeholder)}"`) : ''}>`;
  K.select = (label, name, options, selected, attrs = '') => html`<label for="f-${name}">${label}</label><select id="f-${name}" name="${name}" ${K.raw(attrs)}>${options.map((o) => html`<option value="${o.value}" ${String(o.value) === String(selected) ? K.raw('selected') : ''}>${o.label}</option>`)}</select>`;
  K.table = (cols, rows, empty) => rows.length
    ? html`<div class="tbl"><table><thead><tr>${cols.map((c) => html`<th class="${c.num ? 'num' : ''}">${c.h}</th>`)}</tr></thead><tbody>${rows.map((r) => html`<tr>${r.map((c, i) => html`<td class="${cols[i]?.num ? 'num' : ''}">${c}</td>`)}</tr>`)}</tbody></table></div>`
    : html`<div class="empty">${empty || '—'}</div>`;
  K.errBox = (e) => html`<div class="err">${e.message || e}</div>`;

  // ---------- navigation ----------
  const MEMBER_NAV = [['home', '🏠', 'nav_home'], ['pay', '💳', 'nav_pay'], ['draws', '🎯', 'nav_draws'], ['alerts', '🔔', 'nav_alerts'], ['profile', '👤', 'nav_profile']];
  const ADMIN_NAV = [['dashboard', '📊', 'nav_dashboard', null], ['members', '👥', 'nav_members', 'members'], ['entries', '🪙', 'nav_entries', 'entries'], ['payments', '💳', 'nav_payments', 'payments'], ['draw', '🎯', 'nav_draw', 'draw'],
    ['prizes', '🏆', 'nav_prizes', 'prizes'], ['reminders', '💬', 'nav_reminders', 'reminders'], ['reports', '📑', 'nav_reports', 'reports'], ['announce', '📣', 'nav_announce', 'announce'],
    ['settings', '⚙️', 'nav_settings', 'settings'], ['audit', '🛡️', 'nav_audit', 'audit'], ['backups', '💾', 'nav_backups', 'backups'], ['admins', '🔑', 'nav_admins', 'manage_admins']];
  K.adminNav = () => ADMIN_NAV.filter((n) => !n[3] || K.state.auth.permissions.includes(n[3]));
  K.can = (p) => K.state.auth?.role === 'admin' && K.state.auth.permissions.includes(p);

  K.route = () => (location.hash.replace(/^#\/?/, '') || '').split('?')[0];
  K.go = (r) => { if (K.route() === r) K.render(); else location.hash = '#/' + r; };

  function chrome(inner, current) {
    const a = K.state.auth;
    const isAdmin = a.role === 'admin';
    const nav = isAdmin ? K.adminNav() : MEMBER_NAV;
    const unread = K.state.unread || 0;
    const link = (n) => html`<a href="#/${n[0]}" class="${current === n[0] ? 'on' : ''}"><span class="ic">${n[1]}</span><span>${t(n[2])}</span>${n[0] === 'alerts' && unread ? html`<span class="badge">${unread}</span>` : ''}${n[0] === 'payments' && K.state.pendingPayments ? html`<span class="badge">${K.state.pendingPayments}</span>` : ''}</a>`;
    const bottom = isAdmin ? [nav[0], nav.find((n) => n[0] === 'members'), nav.find((n) => n[0] === 'payments'), nav.find((n) => n[0] === 'draw')].filter(Boolean) : nav;
    return html`
      <header class="hdr">
        <img src="/icons/icon-192.png" alt=""><span class="brand">KURI</span><span class="sp"></span>
        <button class="lang" data-act="toggle-lang" aria-label="${t('language')}">${K.state.lang === 'en' ? 'മലയാളം' : 'English'}</button>
        <button data-act="logout">${t('logout')}</button>
      </header>
      <div class="shell">
        <nav class="side" aria-label="Main">${nav.map(link)}</nav>
        <main id="view" tabindex="-1">${inner}</main>
      </div>
      <nav class="bottom" aria-label="Main">${bottom.map(link)}${isAdmin ? html`<a href="#/menu" class="${current === 'menu' ? 'on' : ''}"><span class="ic">☰</span><span>${t('nav_more')}</span></a>` : ''}</nav>`;
  }

  K.render = async () => {
    const app = document.getElementById('app');
    const a = K.state.auth;
    if (!a) { app.innerHTML = K.views.login().s; return; }
    if (a.role === 'admin' && a.must_change_pw) { app.innerHTML = K.views.forcePassword().s; return; }
    let r = K.route();
    const defaultRoute = a.role === 'admin' ? 'dashboard' : 'home';
    if (!r) r = defaultRoute;
    const table = a.role === 'admin' ? K.views.admin : K.views.member;
    if (a.role === 'admin' && r === 'menu') {
      app.innerHTML = chrome(html`<h1>${t('nav_more')}</h1><div class="card menu-list" style="padding:0">${K.adminNav().map((n) => html`<a href="#/${n[0]}"><span class="ic">${n[1]}</span>${t(n[2])}</a>`)}</div>`, 'menu').s;
      return;
    }
    const view = table[r] || table[defaultRoute];
    app.innerHTML = chrome(html`<div class="card"><div class="empty">${t('loading')}</div></div>`, r).s;
    const token = (K._renderToken = (K._renderToken || 0) + 1);
    let content;
    try { content = await view(); } catch (e) { content = html`<div class="card"><h2>${t('err_generic')}</h2>${K.errBox(e)}<button data-act="retry">${t('retry')}</button></div>`; }
    if (token !== K._renderToken) return; // a newer navigation superseded this one
    app.innerHTML = chrome(content, r).s;
    window.scrollTo(0, 0);
  };

  // ---------- event delegation (CSP forbids inline handlers) ----------
  document.addEventListener('click', async (ev) => {
    const el = ev.target.closest('[data-act]');
    if (!el) return;
    const act = el.dataset.act;
    if (act === 'modal-bg') { if (ev.target === el) K.closeModal(); return; }
    if (el.tagName === 'A' && !act) return;
    ev.preventDefault?.();
    const fn = K.actions[act];
    if (!fn) return;
    if (el.dataset.busy) return;
    el.dataset.busy = '1'; const wasDisabled = el.disabled;
    try { await fn(el, ev); } catch (e) { K.toast(e.message || t('err_generic'), true); }
    finally { delete el.dataset.busy; if (document.body.contains(el)) el.disabled = wasDisabled; }
  });
  document.addEventListener('submit', async (ev) => {
    const form = ev.target.closest('form[data-submit]');
    if (!form) return;
    ev.preventDefault();
    const fn = K.submits[form.dataset.submit];
    if (!fn) return;
    const btn = form.querySelector('button[type=submit],button:not([type])');
    if (btn) btn.disabled = true;
    const errBox = form.querySelector('.form-err'); if (errBox) errBox.innerHTML = '';
    try { await fn(form, K.formData(form)); }
    catch (e) { if (errBox) errBox.innerHTML = `<div class="err">${esc(e.message)}</div>`; else K.toast(e.message, true); }
    finally { if (btn && document.body.contains(btn)) btn.disabled = false; }
  });

  K.actions['toggle-lang'] = async () => {
    const l = K.state.lang === 'en' ? 'ml' : 'en';
    K.setLang(l);
    if (K.state.auth?.role === 'member') { try { await K.api('PATCH', '/api/me/profile', { language: l }); } catch (_) {} }
    K.render();
  };
  K.actions.logout = async () => { try { await K.post('/api/auth/logout'); } catch (_) {} K.state.auth = null; K.state.cache = {}; location.hash = ''; K.render(); };
  K.actions.retry = () => K.render();
  K.actions['confirm-yes'] = () => { K.closeModal(); K._confirm?.(true); };
  K.actions['confirm-no'] = () => { K.closeModal(); K._confirm?.(false); };
  K.actions['prompt-yes'] = () => { const v = document.getElementById('prompt-input').value; K.closeModal(); K._prompt?.(v); };
  K.actions['prompt-no'] = () => { K.closeModal(); K._prompt?.(null); };
  K.actions['close-modal'] = () => K.closeModal();
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') K.closeModal(); });
  window.addEventListener('hashchange', () => K.render());
})();
