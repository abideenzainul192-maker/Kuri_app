(function () {
  const { html, t, inr, fdate, fdt, chip, api } = { html: K.html, t: K.t, inr: K.inr, fdate: K.fdate, fdt: K.fdt, chip: K.chip, api: K.api };
  K.views.member = {};
  const V = K.views.member;

  // ---------------- login (shared member / admin) ----------------
  K.views.login = () => {
    const mode = K.state.loginMode || 'member';
    const step = K.state.otpStep || 1;
    return html`
    <div class="login">
      <img class="logo" src="/icons/icon-512.png" alt="KURI">
      <h1>KURI</h1><p class="tag">${t('app_tagline')}</p>
      <div class="row" style="justify-content:center;margin-bottom:.6rem">
        <button class="sm sec" data-act="toggle-lang">${K.state.lang === 'en' ? 'മലയാളം' : 'English'}</button>
      </div>
      <div class="tabs" style="justify-content:center">
        <button class="${mode === 'member' ? 'on' : ''}" data-act="login-mode" data-mode="member">${t('member')}</button>
        <button class="${mode === 'admin' ? 'on' : ''}" data-act="login-mode" data-mode="admin">${t('admin')}</button>
      </div>
      <div class="card">
      ${mode === 'member' ? (step === 1 ? html`
        <form data-submit="otp-request"><div class="form-err"></div>
          ${K.field(t('phone'), 'phone', { type: 'tel', required: true, placeholder: '9876543210', attrs: 'autocomplete="tel" inputmode="tel"' })}
          <p class="note">${t('only_registered')}</p>
          <button class="block" type="submit">${t('send_otp')}</button>
        </form>` : html`
        <form data-submit="otp-verify"><div class="form-err"></div>
          <p class="mut">${t('otp_sent')}</p>
          ${K.state.devOtp ? html`<div class="warn">${t('dev_otp_hint')}: <b class="mono">${K.state.devOtp}</b></div>` : ''}
          ${K.field(t('enter_otp'), 'code', { required: true, attrs: 'inputmode="numeric" maxlength="6" autocomplete="one-time-code" pattern="\\d{6}"' })}
          <button class="block" type="submit" style="margin-top:.8rem">${t('verify_login')}</button>
          <button class="block sec" type="button" data-act="otp-back" style="margin-top:.5rem">${t('back')}</button>
        </form>`)
      : html`
        <form data-submit="admin-login"><div class="form-err"></div>
          ${K.field(t('phone'), 'phone', { type: 'tel', required: true, attrs: 'autocomplete="username"' })}
          ${K.field(t('password'), 'password', { type: 'password', required: true, attrs: 'autocomplete="current-password"' })}
          <button class="block" type="submit" style="margin-top:.9rem">${t('sign_in')}</button>
        </form>`}
      </div>
      <p class="note" style="text-align:center">🔒 ${K.state.lang === 'ml' ? 'സുരക്ഷിത കണക്ഷൻ' : 'Secure connection'}</p>
    </div>`;
  };
  K.views.forcePassword = () => html`
    <div class="login"><img class="logo" src="/icons/icon-512.png" alt="KURI"><h1>KURI</h1>
      <div class="card"><h2>Set a new password</h2><p class="mut">For security, change the temporary password before continuing.</p>
      <form data-submit="change-pw"><div class="form-err"></div>
        ${K.field('Current (temporary) password', 'current', { type: 'password', required: true, attrs: 'autocomplete="current-password"' })}
        ${K.field('New password (10+ characters, letters and numbers)', 'new', { type: 'password', required: true, attrs: 'autocomplete="new-password" minlength="10"' })}
        <button class="block" type="submit" style="margin-top:.9rem">${t('save')}</button></form>
        <button class="block sec" data-act="logout" style="margin-top:.6rem">${t('logout')}</button></div></div>`;

  K.actions['login-mode'] = (el) => { K.state.loginMode = el.dataset.mode; K.state.otpStep = 1; K.state.devOtp = null; K.render(); };
  K.actions['otp-back'] = () => { K.state.otpStep = 1; K.state.devOtp = null; K.render(); };
  K.submits['otp-request'] = async (f, d) => {
    const r = await K.post('/api/auth/otp/request', { phone: d.phone });
    K.state.loginPhone = d.phone; K.state.otpStep = 2; K.state.devOtp = r.dev_otp || null; K.render();
  };
  K.submits['otp-verify'] = async (f, d) => {
    await K.post('/api/auth/otp/verify', { phone: K.state.loginPhone, code: d.code });
    await K.boot();
  };
  K.submits['admin-login'] = async (f, d) => { await K.post('/api/auth/admin/login', d); await K.boot(); };
  K.submits['change-pw'] = async (f, d) => { await K.post('/api/auth/admin/change-password', d); K.toast(t('saved')); await K.boot(); };

  // ---------------- home ----------------
  const stLabel = (s) => K.statusLabel(s);
  function ledgerTable(e) {
    return K.table(
      [{ h: t('month') }, { h: t('due_date') }, { h: t('due'), num: 1 }, { h: t('paid'), num: 1 }, { h: t('balance'), num: 1 }, { h: t('status') }],
      e.ledger.map((l) => [l.month_no, fdate(l.due_date), inr(l.due), inr(l.paid), inr(l.remaining), chip(l.status, stLabel(l.status))]));
  }
  V.home = async () => {
    const o = (K.state.cache.overview = await K.get('/api/me/overview'));
    K.state.unread = o.unread;
    const lang = K.state.lang;
    return html`
      <h1>${t('hello')}, ${o.member.name.split(' ')[0]} 👋</h1>
      ${!o.entries.length ? html`<div class="card"><p>${t('no_entry')}</p></div>` : ''}
      ${o.entries.map((e) => html`
        ${e.won ? html`<div class="card gold"><h2>🏆 ${t('won_title')}</h2>
          <div class="grid g2"><div><div class="mut">${t('winning_month')}</div><b>${e.won.month_no}</b></div>
          <div><div class="mut">${e.type === 'team' ? t('my_prize_share') + ' (' + e.won.my_share_percent + '%)' : t('prize_amount')}</div><b class="big">${inr(e.won.my_share_amount)}</b></div></div>
          <p class="mut">${t('prize_amount')}: ${inr(e.won.amount)} · ${t('prize_status')}: ${chip(e.won.status === 'paid' ? 'paid' : 'pending', e.won.status === 'paid' ? t('prize_paid') : t('prize_pending'))}${e.won.paid_date ? ` · ${t('paid_on')} ${fdate(e.won.paid_date)}` : ''}</p></div>` : ''}
        <div class="card hero">
          <div class="row sb"><span class="mut">${t('my_entry')}</span><span class="chip gold">${e.label} · ${e.type === 'team' ? t('team_entry') : t('individual_entry')}</span></div>
          <div class="mut" style="margin-top:.6rem">${t('outstanding')}</div>
          <div class="big">${inr(e.outstanding_to_date)}</div>
          <div class="row" style="margin-top:.4rem"><span>${t('my_share')}: <b>${inr(e.my_share)}</b></span><span>${t('total_paid')}: <b>${inr(e.total_paid)}</b></span></div>
          ${e.outstanding_to_date > 0 ? html`<a href="#/pay" class="btn gold block" style="margin-top:.8rem">${t('pay_title')}</a>` : html`<p style="margin:.6rem 0 0">✅ ${t('nothing_to_pay')}</p>`}
        </div>
        ${e.team ? html`<div class="card"><h2>${t('team_members')}</h2>${K.table([{ h: t('name') }, { h: t('contribution') || t('my_share'), num: 1 }, { h: t('prize_percent'), num: 1 }],
          e.team.map((m) => [m.is_me ? html`<b>${m.name} ★</b>` : m.name, inr(m.monthly_share), m.prize_percent + '%']))}</div>` : ''}
        <div class="card"><h2>${t('ledger')}</h2>${ledgerTable(e)}</div>`)}
      <div class="card"><h2>${t('rules')}</h2><p style="white-space:pre-wrap;margin:0">${lang === 'ml' ? o.settings.rules_ml || o.settings.rules_en : o.settings.rules_en}</p></div>
      ${installCard()}`;
  };

  // ---------------- PWA install help ----------------
  let deferredPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredPrompt = e; });
  function installCard() {
    if (window.matchMedia('(display-mode: standalone)').matches || navigator.standalone) return '';
    return html`<div class="card"><h2>📲 ${t('install_title')}</h2>
      ${deferredPrompt ? html`<button class="block" data-act="install">${t('install_btn')}</button>` : ''}
      <p class="mut">${t('install_android')}</p><p class="mut">${t('install_ios')}</p></div>`;
  }
  K.actions.install = async () => { if (!deferredPrompt) return; deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt = null; K.render(); };

  // ---------------- pay ----------------
  V.pay = async () => {
    const o = (K.state.cache.overview = await K.get('/api/me/overview'));
    K.state.unread = o.unread;
    const s = o.settings;
    const openItems = [];
    for (const e of o.entries) for (const l of e.ledger) {
      const open = l.remaining - l.pending;
      if (l.due_date <= o.today && open > 0) openItems.push({ entry: e, l, open });
    }
    const payUri = s.collection_upi_id ? `upi://pay?pa=${encodeURIComponent(s.collection_upi_id)}&pn=${encodeURIComponent(s.collection_payee_name || 'KURI')}&cu=INR` : null;
    return html`
      <h1>${t('pay_title')}</h1>
      <div class="card">
        <p class="mut">${t('pay_hint')}</p>
        ${s.collection_upi_id ? html`<div class="stat"><span>${t('pay_to')}</span><b class="mono" style="font-size:1rem">${s.collection_upi_id}</b>${s.collection_payee_name ? html`<span>${s.collection_payee_name}</span>` : ''}</div>
          <div class="row" style="margin-top:.6rem"><button class="sm sec" data-act="copy" data-text="${s.collection_upi_id}">${t('copy')}</button><a class="btn sm sec" href="${payUri}">${t('open_upi')}</a></div>` : ''}
        <div class="warn">${t('not_proof')}</div>
      </div>
      ${openItems.length ? html`<div class="card"><form data-submit="pay"><div class="form-err"></div>
        ${K.select(t('entry') + ' / ' + t('month'), 'sel', openItems.map((x, i) => ({ value: i, label: `${x.entry.label} · ${t('month')} ${x.l.month_no} · ${inr(x.open)}` })), 0, 'data-act="pay-sel"')}
        ${K.field(t('amount') + ' (₹)', 'amount', { type: 'number', required: true, value: openItems[0].open, attrs: `min="1" max="${openItems[0].open}" step="1" inputmode="numeric"` })}
        ${K.select(t('method'), 'method', [{ value: 'upi', label: 'UPI' }, { value: 'bank', label: 'Bank transfer' }], 'upi')}
        ${K.field(t('txn_ref'), 'txn_ref', { required: true, attrs: 'minlength="6" maxlength="40" autocapitalize="characters" autocomplete="off"', placeholder: '4xxxxxxxxxxx' })}
        ${K.field(t('paid_date'), 'paid_on', { type: 'date', attrs: `max="${o.today}"`, value: o.today })}
        <input type="hidden" name="entry_id" value="${openItems[0].entry.id}"><input type="hidden" name="month_no" value="${openItems[0].l.month_no}">
        <button class="block" type="submit" style="margin-top:1rem">${t('submit_payment')}</button></form></div>
        <script type="application/json" id="open-items">${K.raw(JSON.stringify(openItems.map((x) => ({ e: x.entry.id, m: x.l.month_no, o: x.open }))).replace(/</g, '\\u003c'))}</script>`
      : html`<div class="card"><div class="empty">✅ ${t('nothing_to_pay')}</div></div>`}
      <div class="card"><h2>${t('my_submissions')}</h2>
        ${K.table([{ h: t('month') }, { h: t('amount'), num: 1 }, { h: t('txn_ref') }, { h: t('status') }],
          o.payments.map((p) => [p.month_no, inr(p.amount), html`<span class="mono">${p.txn_ref || '—'}</span>`, html`${chip(p.status, t(p.status))}${p.reject_reason ? html`<div class="note">${p.reject_reason}</div>` : ''}`]), t('none'))}
      </div>`;
  };
  // The select is wired through a change listener (CSP-safe, no inline handlers)
  document.addEventListener('change', (ev) => {
    const el = ev.target;
    if (el.dataset?.act !== 'pay-sel') return;
    try {
      const items = JSON.parse(document.getElementById('open-items').textContent);
      const it = items[Number(el.value)], f = el.form;
      f.elements.entry_id.value = it.e; f.elements.month_no.value = it.m;
      f.elements.amount.value = it.o; f.elements.amount.max = it.o;
    } catch (_) {}
  });
  K.submits.pay = async (f, d) => {
    await K.post('/api/me/payments', { entry_id: d.entry_id, month_no: Number(d.month_no), amount: d.amount, method: d.method, txn_ref: d.txn_ref, paid_on: d.paid_on });
    K.toast(t('payment_submitted')); K.render();
  };
  K.actions.copy = async (el) => { try { await navigator.clipboard.writeText(el.dataset.text); K.toast(t('copied')); } catch (_) { K.toast(el.dataset.text); } };

  // ---------------- draws ----------------
  V.draws = async () => {
    const draws = await K.get('/api/draws');
    return html`<h1>${t('draws_title')}</h1>
      ${draws.length ? draws.map((d) => html`<div class="card ${d.is_mine ? 'gold' : ''}">
        <div class="row sb"><h2 style="margin:0">${t('month')} ${d.month_no}</h2><span class="mut">${fdt(d.drawn_at)}</span></div>
        ${d.is_mine ? html`<p><b>🎉 ${t('you_won')}</b></p>` : ''}
        <div style="margin:.5rem 0">${d.winners.map((w) => html`<div class="row sb" style="padding:.35rem 0;border-bottom:1px solid var(--line)">
          <span><b>${w.entry_label}</b> ${w.type === 'team' ? chip('gold', t('team')) : ''}<div class="note">${w.names.join(', ')}</div></span>
          <span>${inr(w.prize_amount)}<div>${chip(w.prize_status === 'paid' ? 'paid' : 'pending', w.prize_status === 'paid' ? t('prize_paid') : t('prize_pending'))}</div></span></div>`)}</div>
        <details><summary>${t('participating')} (${d.eligible_count})</summary><div class="pill-list" style="margin-top:.4rem">${d.participating_entries.map((l) => html`<span class="chip">${l}</span>`)}</div></details>
        <button class="sm sec" data-act="verify-draw" data-id="${d.id}" style="margin-top:.6rem">🔍 ${t('verify_draw')}</button>
      </div>`) : html`<div class="card"><div class="empty">${t('no_draws')}</div></div>`}`;
  };
  K.actions['verify-draw'] = async (el) => {
    const v = await K.get(`/api/draws/${el.dataset.id}/verify`);
    const good = v.winners_match && v.eligible_hash_matches;
    K.modal(html`<h2>${t('verify_draw')} · ${t('month')} ${v.month_no}</h2>
      <div class="${good ? 'ok' : 'err'}">${good ? '✅ ' + t('verified_ok') : '⚠️ ' + t('verified_bad')}</div>
      <p class="note">Algorithm: ${v.algorithm}</p>
      <label>${t('draw_seed')}</label><div class="mono">${v.seed}</div>
      <label>${t('participating')}</label><div class="mono">${JSON.stringify(v.eligible_entry_ids)}</div>
      <div class="sticky-actions"><button data-act="close-modal">${t('close')}</button></div>`);
  };

  // ---------------- alerts ----------------
  V.alerts = async () => {
    const list = await K.get('/api/me/notifications');
    K.post('/api/me/notifications/read').then(() => { K.state.unread = 0; document.querySelectorAll('.badge').forEach((b) => b.remove()); }).catch(() => {});
    return html`<h1>${t('alerts_title')}</h1>
      ${list.length ? list.map((n) => html`<div class="card" style="${n.read_at ? '' : 'border-left:4px solid var(--gold)'}"><div class="row sb"><b>${n.title}</b><span class="note">${fdt(n.created_at)}</span></div><div class="mut">${n.body}</div></div>`)
        : html`<div class="card"><div class="empty">${t('no_alerts')}</div></div>`}`;
  };

  // ---------------- profile ----------------
  V.profile = async () => {
    const o = (K.state.cache.overview = await K.get('/api/me/overview'));
    const m = o.member;
    const st = { none: t('upi_none'), pending: t('upi_pending'), approved: t('upi_approved'), rejected: t('upi_rejected') }[m.upi_status];
    return html`<h1>${t('profile_title')}</h1>
      <div class="card">
        <div class="stat"><span>${t('name')}</span><b>${m.name}</b></div>
        <p class="mut" style="margin:.6rem 0 0">${m.phone}${m.address ? html` · ${m.address}` : ''}</p>
      </div>
      <div class="card"><h2>${t('pref_lang')}</h2>
        <div class="row"><button class="${K.state.lang === 'en' ? '' : 'sec'}" data-act="set-lang" data-lang="en">English</button><button class="${K.state.lang === 'ml' ? '' : 'sec'}" data-act="set-lang" data-lang="ml">മലയാളം</button></div>
        <label class="chk" style="margin-top:1rem"><input type="checkbox" data-act="wa-toggle" ${m.whatsapp_opt_in ? K.raw('checked') : ''}> <span>${t('wa_optin')}<div class="note">${t('wa_optin_hint')}</div></span></label>
      </div>
      <div class="card"><h2>${t('upi_title')}</h2><p class="mut">${t('upi_hint')}</p>
        <p>${t('upi_status')}: ${chip(m.upi_status === 'approved' ? 'approved' : m.upi_status === 'pending' ? 'pending' : m.upi_status === 'rejected' ? 'rejected' : 'none', st)}</p>
        ${m.upi_note ? html`<div class="err">${m.upi_note}</div>` : ''}
        ${m.has_qr ? html`<img class="qr" src="/api/me/upi/qr?t=${Date.now()}" alt="UPI QR">` : ''}
        <form data-submit="upi"><div class="form-err"></div>
          ${K.field(t('upi_id'), 'upi_id', { value: m.upi_id || '', placeholder: 'name@bank', attrs: 'autocapitalize="none" autocomplete="off"' })}
          <label for="f-qr">${t('upi_qr')}</label><input id="f-qr" name="qr" type="file" accept="image/png,image/jpeg,image/webp">
          <button class="block" type="submit" style="margin-top:.9rem">${t('save')}</button></form></div>
      ${installCard()}`;
  };
  K.actions['set-lang'] = async (el) => { K.setLang(el.dataset.lang); try { await K.api('PATCH', '/api/me/profile', { language: el.dataset.lang }); } catch (_) {} K.render(); };
  document.addEventListener('change', async (ev) => {
    if (ev.target.dataset?.act !== 'wa-toggle') return;
    try { await K.api('PATCH', '/api/me/profile', { whatsapp_opt_in: ev.target.checked }); K.toast(t('saved')); } catch (e) { K.toast(e.message, true); ev.target.checked = !ev.target.checked; }
  });
  K.submits.upi = async (f, d) => {
    const file = f.elements.qr.files[0];
    const body = { upi_id: d.upi_id || '' };
    if (file) {
      if (file.size > 1.5 * 1024 * 1024) throw new Error('Image is too large (max 1.5 MB)');
      body.qr_base64 = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
    }
    await K.post('/api/me/upi', body);
    K.toast(t('upi_saved')); K.render();
  };
})();
