/* KURI bootstrap: load session, render, register the service worker. */
(function () {
  K.boot = async () => {
    try { K.state.auth = await K.get('/api/auth/me'); } catch (_) { K.state.auth = null; }
    if (K.state.auth && !K.state.auth.role) K.state.auth = null;
    if (K.state.auth?.role === 'member') {
      // honour the member's saved language on a fresh device
      try { const l = K.state.auth.language; if (l && !localStorage.getItem('kuri_lang')) K.setLang(l); } catch (_) {}
    }
    K.state.otpStep = 1; K.state.devOtp = null;
    if (location.hash === '#/menu' && K.state.auth?.role !== 'admin') location.hash = '';
    await K.render();
  };

  K.boot();

  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  }
})();
