/* KURI admin screens, part 2: draw, prizes, WhatsApp reminders, reports, announcements, audit, backups, administrators. */
(function () {
  const { html, t, inr, fdate, fdt, chip } = { html: K.html, t: K.t, inr: K.inr, fdate: K.fdate, fdt: K.fdt, chip: K.chip };
  const V = K.views.admin;
  const modalClose = () => html`<button class="sec" type="button" data-act="close-modal">${t('cancel')}</button>`;
  const tabs = (items, current, act) => html`<div class="tabs">${items.map(([v, label]) => html`<button class="${current === v ? 'on' : ''}" data-act="${act}" data-v="${v}">${label}</button>`)}</div>`;
  const today = () => new Date().toISOString().slice(0, 10);

  // ======================================================================= draw
  const REASON = { inactive: 'Entry inactive', already_won: 'Already won', unpaid: 'Unpaid balance' };
  V.draw = async () => {
    const months = await K.get('/api/admin/months');
    const draws = await K.get('/api/admin/draws');
    const next = months.find((m) => !m.draw_id);
    let elig = null;
    if (next) { try { elig = await K.get(`/api/admin/draw/eligibility?month_no=${next.month_no}`); } catch (_) {} }
    const canRun = next && next.draw_date <= today();
    return html`<h1>${t('draw_title')}</h1>
      ${!months.length ? html`<div class="card gold"><p>${t('setup_cycle_hint')}</p><a class="btn" href="#/settings">${t('nav_settings')}</a></div>` : ''}
      ${next ? html`<div class="card"><div class="row sb"><h2 style="margin:0">${t('month')} ${next.month_no}</h2><span class="mut">${t('draw_title')}: ${fdate(next.draw_date)}</span></div>
        ${elig ? html`<p><b>${elig.eligible.length}</b> eligible entries · ${elig.excluded.length} excluded</p>
          <div class="pill-list">${elig.eligible.map((e) => html`<span class="chip paid">${e.label}</span>`)}</div>
          ${elig.excluded.length ? html`<details><summary>Excluded (${elig.excluded.length})</summary><div class="pill-list" style="margin-top:.4rem">${elig.excluded.map((e) => html`<span class="chip rejected">${e.label} · ${REASON[e.reason] || e.reason}</span>`)}</div></details>` : ''}` : ''}
        <p class="note">The winner is chosen on the server using a cryptographically secure random seed. The seed, eligible list and rules are stored permanently; anyone can verify the result. Administrators cannot choose or change the outcome, and a drawn month cannot be redone.</p>
        ${canRun ? html`<button class="gold block" data-act="draw-run" data-month="${next.month_no}">🎯 ${t('run_draw')} · ${t('month')} ${next.month_no}</button>` : html`<div class="warn">The draw can only be run on or after ${fdate(next.draw_date)}.</div>`}</div>`
        : (months.length ? html`<div class="card"><div class="empty">✅ All months have been drawn.</div></div>` : '')}
      <h2>Draw history</h2>
      ${draws.length ? draws.map((d) => html`<div class="card"><div class="row sb"><h3 style="margin:0">${t('month')} ${d.month_no}</h3><span class="mut">${fdt(d.drawn_at)} · ${d.triggered_by}</span></div>
        ${d.winners.map((w) => html`<div class="row sb" style="padding:.3rem 0;border-bottom:1px solid var(--line)"><span><b>${w.entry_label}</b> ${w.type === 'team' ? chip('gold', t('team')) : ''}<div class="note">${w.names.join(', ')}</div></span><span>${inr(w.prize_amount)}</span></div>`)}
        <p class="note">${t('participating')}: ${d.participating_entries.join(', ') || '—'}</p>
        <button class="sm sec" data-act="admin-verify-draw" data-id="${d.id}">🔍 ${t('verify_draw')}</button></div>`) : html`<div class="card"><div class="empty">${t('no_draws')}</div></div>`}`;
  };
  K.actions['draw-run'] = async (el) => {
    if (!(await K.confirm(t('run_draw'), `Run the draw for month ${el.dataset.month}? This is final and cannot be undone or repeated.`, t('run_draw')))) return;
    const d = await K.post('/api/admin/draw/run', { month_no: Number(el.dataset.month) });
    K.modal(html`<h2>🎉 ${t('month')} ${d.month_no}</h2><p>${d.winners.length} winning ${d.winners.length === 1 ? 'entry' : 'entries'} selected from ${d.eligible.length} eligible.</p><div class="sticky-actions"><button data-act="close-modal">${t('close')}</button></div>`);
    K.render();
  };
  K.actions['admin-verify-draw'] = async (el) => {
    const v = await K.get(`/api/admin/draws/${el.dataset.id}/verify`);
    const good = v.winners_match && v.eligible_hash_matches;
    K.modal(html`<h2>${t('verify_draw')} · ${t('month')} ${v.month_no}</h2><div class="${good ? 'ok' : 'err'}">${good ? '✅ ' + t('verified_ok') : '⚠️ ' + t('verified_bad')}</div>
      <p class="note">${v.algorithm}</p><label>${t('draw_seed')}</label><div class="mono">${v.seed}</div><label>${t('participating')} (IDs)</label><div class="mono">${JSON.stringify(v.eligible_entry_ids)}</div>
      <div class="sticky-actions"><button data-act="close-modal">${t('close')}</button></div>`);
  };

  // ======================================================================= prizes
  V.prizes = async () => {
    const list = await K.get('/api/admin/prizes');
    return html`<h1>${t('prizes_title')}</h1>
      ${list.length ? list.map((p) => html`<div class="card">
        <div class="row sb"><h2 style="margin:0">${p.label} · ${t('month')} ${p.month_no}</h2><b>${inr(p.amount)}</b></div>
        <p>${chip(p.status === 'paid' ? 'paid' : 'pending', p.status === 'paid' ? t('prize_paid') : t('prize_pending'))} ${p.paid_date ? html`${t('paid_on')} ${fdate(p.paid_date)} ${p.payment_ref ? html`· <span class="mono">${p.payment_ref}</span>` : ''}` : ''}</p>
        ${K.table([{ h: t('name') }, { h: t('prize_percent'), num: 1 }, { h: t('amount'), num: 1 }], p.shares.map((s) => [s.name, s.percent + '%', inr(s.amount)]))}
        ${p.status === 'pending' ? html`<button class="sm" data-act="prize-pay" data-id="${p.id}" style="margin-top:.5rem">${t('mark_paid')}</button>` : ''}</div>`)
        : html`<div class="card"><div class="empty">${t('no_draws')}</div></div>`}`;
  };
  K.actions['prize-pay'] = (el) => K.modal(html`<h2>${t('mark_paid')}</h2><p class="note">Only mark as paid after the money has actually been sent to the winner(s).</p>
    <form data-submit="prize-pay" data-id="${el.dataset.id}"><div class="form-err"></div>${K.field(t('paid_date'), 'paid_date', { type: 'date', value: today(), required: true })}
    ${K.field('Payment reference', 'payment_ref', { attrs: 'maxlength="60"' })}${K.field('Note', 'note')}<div class="sticky-actions">${modalClose()}<button type="submit">${t('save')}</button></div></form>`);
  K.submits['prize-pay'] = async (f, d) => { await K.post(`/api/admin/prizes/${f.dataset.id}/paid`, d); K.closeModal(); K.toast(t('saved')); K.render(); };

  // ======================================================================= reminders
  V.reminders = async () => {
    const tab = K.state.remTab || 'schedules';
    const data = await K.get('/api/admin/reminders');
    let body;
    if (tab === 'schedules') {
      body = data.reminders.length ? data.reminders.map((r) => html`<div class="card">
        <div class="row sb"><h2 style="margin:0">${r.entry_label}</h2>${chip(r.status, r.status)}</div>
        <div class="mut">${t('month')} ${r.month_no} · ${t('due_date')} ${fdate(r.due_date)} · ${t('outstanding')}: <b>${inr(r.outstanding_now)}</b></div>
        <div class="note">${fdate(r.start_date)} → ${r.end_date ? fdate(r.end_date) : '—'} · ${r.interval_days ? `every ${r.interval_days} day(s)` : ''} ${r.custom_dates.length ? `+ ${r.custom_dates.length} custom date(s)` : ''}</div>
        <div style="margin:.3rem 0">${r.next_run_at ? html`Next: <b>${fdt(r.next_run_at)}</b>` : html`<span class="mut">${r.stop_reason ? 'Ended: ' + r.stop_reason.replace('_', ' ') : 'No further reminders'}</span>`}</div>
        <div class="pill-list">${Object.entries(r.message_counts).map(([k, v]) => html`${chip(k, `${k}: ${v}`)}`)}</div>
        <div class="row" style="margin-top:.5rem">${r.status === 'active' ? html`<button class="sm sec" data-act="rem-act" data-id="${r.id}" data-a="pause">⏸ Pause</button>` : ''}
        ${r.status === 'paused' ? html`<button class="sm sec" data-act="rem-act" data-id="${r.id}" data-a="resume">▶ Resume</button>` : ''}
        ${['active', 'paused'].includes(r.status) ? html`<button class="sm danger" data-act="rem-act" data-id="${r.id}" data-a="stop">⏹ Stop</button>` : ''}
        <button class="sm sec" data-act="rem-msgs" data-id="${r.id}">Messages</button></div></div>`)
        : html`<div class="card"><div class="empty">${t('none')}</div></div>`;
    } else {
      const msgs = await K.get('/api/admin/messages');
      body = html`<div class="card" style="padding:.4rem">${K.table([{ h: t('date') }, { h: t('name') }, { h: t('amount'), num: 1 }, { h: t('status') }, { h: 'Detail' }],
        msgs.map((m) => [fdt(m.created_at), html`${m.member_name}<div class="note">${m.phone}</div>`, inr(m.amount), chip(m.status, m.status), m.error ? html`<span class="note" style="color:var(--red)">${m.error}</span>` : (m.provider_message_id ? html`<span class="mono">${m.provider_message_id.slice(-10)}</span>` : '')]), t('none'))}</div>`;
    }
    return html`<div class="row sb"><h1>${t('reminders_title')}</h1><button data-act="rem-new">+ New</button></div>
      ${data.whatsapp_configured ? '' : html`<div class="warn"><b>WhatsApp Business API is not configured.</b> Reminders are scheduled and recorded, but messages are marked <b>failed</b> (never "sent") until credentials are set. See docs/SETUP.md.</div>`}
      <div class="note" style="margin-bottom:.5rem">Reminders run on the server, so they continue even if your phone is off or the app is closed. "Accepted" means WhatsApp took the message; only "delivered/read" is confirmed delivery.</div>
      ${tabs([['schedules', 'Schedules'], ['messages', 'Message log']], tab, 'rem-tab')}${body}
      <button class="sm sec" data-act="rem-run">Run due reminders now</button>`;
  };
  K.actions['rem-tab'] = (el) => { K.state.remTab = el.dataset.v; K.render(); };
  K.actions['rem-run'] = async () => { await K.post('/api/admin/reminders/run-now'); K.toast('Done'); K.render(); };
  K.actions['rem-act'] = async (el) => {
    if (el.dataset.a === 'stop' && !(await K.confirm('Stop reminder', 'No further reminders will be sent for this schedule.', 'Stop'))) return;
    await K.post(`/api/admin/reminders/${el.dataset.id}/action`, { action: el.dataset.a }); K.toast(t('saved')); K.render();
  };
  K.actions['rem-msgs'] = (el) => { K.state.remTab = 'messages'; K.render(); };
  K.actions['rem-new'] = async () => {
    const [entries, months] = await Promise.all([K.get('/api/admin/entries'), K.get('/api/admin/months')]);
    if (!months.length) throw new Error(t('setup_cycle_hint'));
    const cur = months.filter((m) => m.due_date <= today()).pop() || months[0];
    K.modal(html`<h2>New WhatsApp reminder</h2><form data-submit="rem-new"><div class="form-err"></div>
      ${K.select(t('entry') + ' (individual or team)', 'entry_id', entries.filter((e) => e.status === 'active').map((e) => ({ value: e.id, label: `${e.label} · ${e.type === 'team' ? t('team') : t('individual')}` })), '')}
      ${K.select(t('month'), 'month_no', months.map((m) => ({ value: m.month_no, label: `${t('month')} ${m.month_no} · ${t('due_date')} ${fdate(m.due_date)}` })), cur.month_no)}
      <p class="note">The outstanding amount is calculated live from verified payments. Partial payments reduce it automatically; full payment stops the reminder.</p>
      ${K.field('Start date', 'start_date', { type: 'date', value: today(), required: true })}
      ${K.field('End date (optional - default: start + period)', 'end_date', { type: 'date' })}
      ${K.select('Keep reminding for', 'period_months', [{ value: 1, label: '1 month' }, { value: 3, label: '3 months' }, { value: 6, label: '6 months' }, { value: 12, label: '1 year' }, { value: 24, label: '2 years' }], 12)}
      ${K.field('Repeat every N days (blank = custom dates only)', 'interval_days', { type: 'number', value: 7, attrs: 'min="1" max="365"' })}
      ${K.field('Extra custom dates (YYYY-MM-DD, comma separated)', 'custom_dates', { placeholder: '2027-01-05, 2027-01-12' })}
      <div class="sticky-actions">${modalClose()}<button type="submit">${t('save')}</button></div></form>`);
  };
  K.submits['rem-new'] = async (f, d) => {
    const custom = (d.custom_dates || '').split(/[\s,]+/).filter(Boolean);
    await K.post('/api/admin/reminders', { entry_id: Number(d.entry_id), month_no: Number(d.month_no), start_date: d.start_date, end_date: d.end_date || undefined, period_months: Number(d.period_months), interval_days: d.interval_days, custom_dates: custom });
    K.closeModal(); K.toast(t('saved')); K.render();
  };

  // ======================================================================= reports
  const REPORTS = [['monthly_collection', 'Monthly collection'], ['member_payments', 'Member-wise payments'], ['team_contribution', 'Team contributions'], ['outstanding', 'Outstanding balances'], ['winners', 'Winner history'], ['prize_distribution', 'Prize distribution'], ['admin_activity', 'Admin activity']];
  V.reports = async () => {
    const cur = K.state.report || 'monthly_collection';
    let rep;
    try { rep = await K.get(`/api/admin/reports/${cur}`); } catch (e) { rep = { title: '', columns: [], rows: [], error: e.message }; }
    return html`<h1>${t('reports_title')}</h1>
      <div class="tabs">${REPORTS.map(([k, l]) => html`<button class="${cur === k ? 'on' : ''}" data-act="rep-pick" data-v="${k}">${l}</button>`)}</div>
      <div class="card"><div class="row sb"><h2 style="margin:0">${rep.title}</h2>
        <span class="row"><a class="btn sm sec" href="/api/admin/reports/${cur}?format=xlsx" download>Excel</a><a class="btn sm sec" href="/api/admin/reports/${cur}?format=pdf" download>PDF</a></span></div>
        ${rep.error ? html`<div class="err">${rep.error}</div>` : ''}${rep.note ? html`<p class="note">${rep.note}</p>` : ''}
        ${K.table(rep.columns.map((h) => ({ h, num: /₹|%/.test(h) })), rep.rows.slice(0, 300), t('none'))}
        ${rep.rows.length > 300 ? html`<p class="note">Showing first 300 of ${rep.rows.length} rows. Export for everything.</p>` : ''}</div>`;
  };
  K.actions['rep-pick'] = (el) => { K.state.report = el.dataset.v; K.render(); };

  // ======================================================================= announcements
  V.announce = async () => {
    const entries = await K.get('/api/admin/entries');
    return html`<h1>${t('announce_title')}</h1><div class="card"><form data-submit="announce"><div class="form-err"></div>
      ${K.field('Title', 'title', { required: true, attrs: 'maxlength="120"' })}
      <label for="f-body">Message</label><textarea id="f-body" name="body" required maxlength="1000"></textarea>
      <details><summary>Send only to selected entries (default: all active members)</summary>
        ${entries.map((e) => html`<label class="chk"><input type="checkbox" name="e${e.id}"> <span>${e.label}</span></label>`)}</details>
      <button class="block" type="submit" style="margin-top:1rem">📣 Send</button></form></div>`;
  };
  K.submits.announce = async (f, d) => {
    const entry_ids = Object.keys(d).filter((k) => /^e\d+$/.test(k) && d[k]).map((k) => Number(k.slice(1)));
    const r = await K.post('/api/admin/announce', { title: d.title, body: d.body, entry_ids });
    K.toast(`Sent to ${r.recipients} member(s)`); f.reset();
  };

  // ======================================================================= audit log
  V.audit = async () => {
    const a = await K.get('/api/admin/audit?limit=300');
    return html`<h1>${t('audit_title')}</h1>
      <div class="${a.chain.ok ? 'ok' : 'err'}">${a.chain.ok ? '🛡️ Hash chain verified: no tampering detected.' : '⚠️ Audit chain broken at entry ' + a.chain.brokenAt}</div>
      <div class="card" style="padding:.4rem">${K.table([{ h: 'Time' }, { h: 'Actor' }, { h: 'Action' }, { h: 'Target' }, { h: 'Detail' }],
        a.rows.map((r) => [fdt(r.at), `${r.actor_type}${r.actor_name ? ': ' + r.actor_name : ''}`, html`<b>${r.action}</b>`, r.target || '', html`<span class="note">${(r.detail || '').slice(0, 160)}</span>`]), t('none'))}</div>`;
  };

  // ======================================================================= backups
  V.backups = async () => {
    const list = await K.get('/api/admin/backups');
    return html`<div class="row sb"><h1>${t('backups_title')}</h1><button data-act="backup-now">+ Back up now</button></div>
      <div class="note" style="margin-bottom:.6rem">The server creates a consistent database backup automatically every day (last 30 kept). Download copies and store them off the server too. To restore, see docs/DEPLOY.md (<span class="mono">npm run restore</span>).</div>
      <div class="card" style="padding:.4rem">${K.table([{ h: 'File' }, { h: 'Created' }, { h: 'Size', num: 1 }, { h: '' }], list.map((b) => [html`<span class="mono">${b.name}</span>`, fdt(b.created), (b.size / 1024).toFixed(0) + ' KB', html`<a class="btn sm sec" href="/api/admin/backups/${b.name}" download>Download</a>`]), t('none'))}</div>`;
  };
  K.actions['backup-now'] = async () => { await K.post('/api/admin/backups'); K.toast('Backup created'); K.render(); };

  // ======================================================================= administrators
  const PERM_LABEL = { members: 'Members', entries: 'Entries & teams', payments: 'Payments & UPI review', draw: 'Run draw', prizes: 'Prizes', reminders: 'WhatsApp reminders', reports: 'Reports', settings: 'Settings & cycle', announce: 'Announcements', backups: 'Backups', audit: 'Audit log', manage_admins: 'Manage administrators' };
  V.admins = async () => {
    const list = await K.get('/api/admin/admins');
    return html`<h1>${t('admins_title')}</h1>
      ${list.map((a) => html`<div class="card"><form data-submit="admin-save" data-id="${a.id}"><div class="form-err"></div>
        <div class="row sb"><h2 style="margin:0">${a.name}</h2>${chip(a.active ? 'active' : 'inactive', a.active ? t('active') : t('inactive'))}</div>
        <div class="grid g2">${K.field(t('name'), 'name', { value: a.name })}${K.field(t('phone'), 'phone', { value: a.phone, type: 'tel' })}</div>
        <label>Permissions</label>${Object.keys(PERM_LABEL).map((p) => html`<label class="chk"><input type="checkbox" name="perm_${p}" ${a.permissions.includes(p) ? K.raw('checked') : ''}> <span>${PERM_LABEL[p]}</span></label>`)}
        <div class="row" style="margin-top:.5rem"><button type="submit">${t('save')}</button>
        <button type="button" class="sec" data-act="admin-reset" data-id="${a.id}">Reset password</button>
        <button type="button" class="${a.active ? 'danger' : 'sec'}" data-act="admin-active" data-id="${a.id}" data-active="${a.active ? 0 : 1}">${a.active ? t('deactivate') : t('activate')}</button></div></form></div>`)}
      <div class="card"><h2>Change my password</h2><form data-submit="change-pw-inline"><div class="form-err"></div>
        ${K.field('Current password', 'current', { type: 'password', required: true })}${K.field('New password (10+ chars, letters & numbers)', 'new', { type: 'password', required: true, attrs: 'minlength="10"' })}
        <button type="submit" style="margin-top:.8rem">${t('save')}</button></form></div>`;
  };
  K.submits['admin-save'] = async (f, d) => {
    const permissions = Object.keys(PERM_LABEL).filter((p) => d['perm_' + p]);
    await K.api('PATCH', `/api/admin/admins/${f.dataset.id}`, { name: d.name, phone: d.phone, permissions });
    K.toast(t('saved')); K.state.auth = await K.get('/api/auth/me'); K.render();
  };
  K.actions['admin-active'] = async (el) => { await K.api('PATCH', `/api/admin/admins/${el.dataset.id}`, { active: el.dataset.active === '1' }); K.toast(t('saved')); K.render(); };
  K.actions['admin-reset'] = async (el) => {
    if (!(await K.confirm('Reset password', 'A temporary password will be shown once. The administrator must change it at next login.', 'Reset'))) return;
    const r = await K.post(`/api/admin/admins/${el.dataset.id}/reset-password`);
    K.modal(html`<h2>Temporary password</h2><div class="mono" style="font-size:1.1rem;padding:.6rem;background:var(--em-l);border-radius:10px">${r.temporary_password}</div><p class="note">${r.note}</p><div class="sticky-actions"><button data-act="close-modal">${t('close')}</button></div>`);
  };
  K.submits['change-pw-inline'] = async (f, d) => { await K.post('/api/auth/admin/change-password', d); f.reset(); K.toast(t('saved')); };
})();
