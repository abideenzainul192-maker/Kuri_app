/* KURI admin screens, part 1: dashboard, members, entries/teams, payments, settings. */
(function () {
  const { html, t, inr, fdate, fdt, chip } = { html: K.html, t: K.t, inr: K.inr, fdate: K.fdate, fdt: K.fdt, chip: K.chip };
  K.views.admin = {};
  const V = K.views.admin;
  K.changes = K.changes || {};
  document.addEventListener('change', (ev) => { const a = ev.target.dataset?.act; if (a && K.changes[a]) K.changes[a](ev.target, ev); });

  // Extra strings (Malayalam falls back to English where missing)
  Object.assign(I18N.en, {
    search_ph: 'Search name or phone', members_count: 'members', no_members: 'No members yet. Add the first member.', save_changes: 'Save changes',
    entry_name: 'Entry name (optional)', entry_type: 'Entry type', members_in_entry: 'Members in this entry', split_equally: 'Split equally', add_row: 'Add person',
    upi_review: 'UPI details review', approve: 'Approve', cannot_see_qr: 'No QR uploaded',
    awaiting: 'Awaiting verification', all: 'All', record_for: 'Member', method_cash: 'Cash', method_bank: 'Bank transfer', method_upi: 'UPI', method_gateway: 'Gateway',
    setup_cycle_hint: 'Set the first due date in Settings, then generate the monthly cycle.', unpaid_amt: 'Unpaid', expected: 'Expected',
    wa_opt_in_admin: 'Member agreed to receive WhatsApp messages (opt-in)', registered: 'Registered entries', capacity: 'capacity',
  });
  Object.assign(I18N.ml, {
    search_ph: 'പേര് / ഫോൺ തിരയുക', members_count: 'അംഗങ്ങൾ', no_members: 'അംഗങ്ങളില്ല. ആദ്യ അംഗത്തെ ചേർക്കുക.', save_changes: 'മാറ്റങ്ങൾ സേവ് ചെയ്യുക',
    entry_name: 'എൻട്രി പേര് (ഐച്ഛികം)', entry_type: 'എൻട്രി തരം', members_in_entry: 'ഈ എൻട്രിയിലെ അംഗങ്ങൾ', split_equally: 'തുല്യമായി വിഭജിക്കുക', add_row: 'ആളെ ചേർക്കുക',
    approve: 'അംഗീകരിക്കുക', awaiting: 'പരിശോധനയ്ക്ക് കാത്തിരിക്കുന്നു', all: 'എല്ലാം',
  });

  const labelOf = (list, id, key = 'label') => list.find((x) => x.id === id)?.[key] ?? '';
  const tabs = (items, current, act) => html`<div class="tabs">${items.map(([v, label]) => html`<button class="${current === v ? 'on' : ''}" data-act="${act}" data-v="${v}">${label}</button>`)}</div>`;
  const modalClose = () => html`<button class="sec" type="button" data-act="close-modal">${t('cancel')}</button>`;

  // ======================================================================= dashboard
  V.dashboard = async () => {
    const d = await K.get('/api/admin/dashboard');
    K.state.pendingPayments = d.pending_payments;
    const c = d.current_month;
    const pct = c && c.expected ? Math.min(100, Math.round((c.paid / c.expected) * 100)) : 0;
    return html`<h1>${t('dash_title')}</h1>
      ${!d.cycle_ready ? html`<div class="card gold"><h2>${t('setup_needed')}</h2><p>${t('setup_cycle_hint')}</p><a class="btn" href="#/settings">${t('nav_settings')}</a></div>` : ''}
      <div class="grid g4">
        <div class="stat"><b>${d.members.active}</b><span>${t('total_members')} (${d.members.total})</span></div>
        <div class="stat"><b>${d.entries.total} / ${d.entries.capacity}</b><span>${t('total_entries')} · ${d.entries.teams} ${t('teams')}</span></div>
        <div class="stat"><b>${inr(d.monthly_collection_target)}</b><span>${t('monthly_collection')}</span></div>
        <div class="stat"><b>${inr(d.total_outstanding)}</b><span>${t('total_outstanding')}</span></div>
      </div>
      ${c ? html`<div class="card" style="margin-top:.9rem"><div class="row sb"><h2 style="margin:0">${t('month')} ${c.month_no}</h2><span class="mut">${t('due_date')} ${fdate(c.due_date)} · ${t('draw_title')} ${fdate(c.draw_date)}</span></div>
        <div class="bar" style="margin:.7rem 0"><i style="width:${pct}%"></i></div>
        <div class="grid g3"><div class="stat"><b>${inr(c.paid)}</b><span>${t('collected')}</span></div><div class="stat"><b>${inr(c.unpaid)}</b><span>${t('unpaid')}</span></div><div class="stat"><b>${inr(c.awaiting_verification)}</b><span>${t('awaiting')}</span></div></div>
        ${c.drawn ? chip('completed', 'Draw done') : ''}</div>` : ''}
      ${d.pending_payments || d.pending_upi_reviews ? html`<div class="card"><h2>${t('pending_verify')} / ${t('upi_review')}</h2>
        ${d.pending_payments ? html`<p><a href="#/payments">${d.pending_payments} ${t('payments_title')} →</a></p>` : ''}
        ${d.pending_upi_reviews ? html`<p><a href="#/members">${d.pending_upi_reviews} ${t('upi_review')} →</a></p>` : ''}</div>` : ''}
      <div class="grid g2" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))">
        <div class="card"><h2>${t('recent_winners')}</h2>${K.table([{ h: t('month') }, { h: t('entry') }, { h: t('amount'), num: 1 }, { h: t('status') }],
          d.recent_winners.map((w) => [w.month_no, w.label, inr(w.amount), chip(w.status === 'paid' ? 'paid' : 'pending', w.status === 'paid' ? t('prize_paid') : t('prize_pending'))]), t('no_draws'))}
          ${d.prizes_pending ? html`<p class="note">${d.prizes_pending} ${t('prize_pending').toLowerCase()} · <a href="#/prizes">${t('prizes_title')}</a></p>` : ''}</div>
        <div class="card"><h2>${t('upcoming_reminders')}</h2>${K.table([{ h: t('entry') }, { h: t('date') }],
          d.upcoming_reminders.map((r) => [r.label, fdt(r.next_run_at)]), t('none'))}
          ${d.failed_messages_30d ? html`<div class="warn">${d.failed_messages_30d} failed WhatsApp messages in the last 30 days · <a href="#/reminders">${t('reminders_title')}</a></div>` : ''}</div>
      </div>`;
  };

  // ======================================================================= members
  V.members = async () => {
    const list = (K.state.cache.members = await K.get('/api/admin/members'));
    const q = (K.state.memberQ || '').toLowerCase();
    const rows = list.filter((m) => !q || m.name.toLowerCase().includes(q) || m.phone.includes(q));
    return html`<div class="row sb"><h1>${t('members_title')} <span class="mut">(${list.length})</span></h1><button data-act="member-add">+ ${t('add_member')}</button></div>
      <input type="search" placeholder="${t('search_ph')}" value="${K.state.memberQ || ''}" data-act="member-search" style="margin-bottom:.8rem">
      <div class="card" style="padding:.4rem">${rows.length ? K.table([{ h: t('name') }, { h: t('phone') }, { h: t('nav_entries') }, { h: 'UPI' }, { h: t('status') }, { h: '' }],
        rows.map((m) => [html`<b>${m.name}</b>`, m.phone, m.entries.map((e) => e.label).join(', ') || '—',
          chip(m.upi_status === 'none' ? 'none' : m.upi_status, t('upi_' + m.upi_status)), chip(m.status, t(m.status)),
          html`<button class="sm sec" data-act="member-edit" data-id="${m.id}">${t('view')}</button>`])) : html`<div class="empty">${t('no_members')}</div>`}</div>`;
  };
  document.addEventListener('input', (ev) => {
    if (ev.target.dataset?.act !== 'member-search') return;
    K.state.memberQ = ev.target.value; clearTimeout(K._mq);
    K._mq = setTimeout(async () => { const pos = ev.target.selectionStart; await K.render(); const i = document.querySelector('[data-act=member-search]'); if (i) { i.focus(); i.setSelectionRange(pos, pos); } }, 250);
  });
  const memberForm = (m) => html`<h2>${m ? t('edit') + ' · ' + m.name : t('add_member')}</h2>
    <form data-submit="member-save" data-id="${m?.id ?? ''}"><div class="form-err"></div>
      ${K.field(t('name'), 'name', { value: m?.name, required: true, attrs: 'maxlength="100"' })}
      ${K.field(t('phone'), 'phone', { type: 'tel', value: m?.phone, required: true, placeholder: '9876543210' })}
      ${K.field(t('address'), 'address', { value: m?.address })}
      <label for="f-registration_details">${t('registration')}</label><textarea id="f-registration_details" name="registration_details" maxlength="1000">${m?.registration_details ?? ''}</textarea>
      ${K.select(t('pref_lang'), 'language', [{ value: 'en', label: 'English' }, { value: 'ml', label: 'മലയാളം' }], m?.language || 'en')}
      <label class="chk"><input type="checkbox" name="whatsapp_opt_in" ${m?.whatsapp_opt_in ? K.raw('checked') : ''}> <span>${t('wa_opt_in_admin')}</span></label>
      <div class="sticky-actions">${modalClose()}<button type="submit">${t('save')}</button></div></form>`;
  K.actions['member-add'] = () => K.modal(memberForm(null));
  K.actions['member-edit'] = async (el) => {
    const id = Number(el.dataset.id);
    const m = K.state.cache.members.find((x) => x.id === id);
    const upi = m.upi_id || m.has_qr ? html`<div class="card" style="margin-top:.8rem"><h3>${t('upi_review')}</h3>
      <p>${chip(m.upi_status === 'none' ? 'none' : m.upi_status, t('upi_' + m.upi_status))} ${m.upi_id ? html`<span class="mono">${m.upi_id}</span>` : ''}</p>
      ${m.has_qr ? html`<img class="qr" src="/api/admin/members/${id}/qr?t=${Date.now()}" alt="QR">` : ''}
      ${m.upi_status === 'pending' ? html`<div class="row"><button class="sm" data-act="upi-approve" data-id="${id}">${t('approve')}</button><button class="sm danger" data-act="upi-reject" data-id="${id}">${t('reject')}</button></div>` : ''}
      <p class="note">QR / UPI ID are never proof of payment. Verify real payments by transaction reference.</p></div>` : '';
    K.modal(html`${memberForm(m)}${upi}
      <div class="sticky-actions"><button class="${m.status === 'active' ? 'danger' : 'sec'}" data-act="member-status" data-id="${id}" data-status="${m.status === 'active' ? 'inactive' : 'active'}">${m.status === 'active' ? t('deactivate') : t('activate')}</button></div>`);
  };
  K.submits['member-save'] = async (f, d) => {
    const body = { name: d.name, phone: d.phone, address: d.address, registration_details: d.registration_details, language: d.language, whatsapp_opt_in: !!d.whatsapp_opt_in };
    const id = f.dataset.id;
    if (id) await K.api('PATCH', `/api/admin/members/${id}`, body); else await K.post('/api/admin/members', body);
    K.closeModal(); K.toast(t('saved')); K.render();
  };
  K.actions['member-status'] = async (el) => {
    const next = el.dataset.status;
    if (next === 'inactive' && !(await K.confirm(t('deactivate'), 'This member will be signed out and can no longer log in.', t('deactivate')))) return;
    await K.post(`/api/admin/members/${el.dataset.id}/status`, { status: next });
    K.closeModal(); K.toast(t('saved')); K.render();
  };
  K.actions['upi-approve'] = async (el) => { await K.post(`/api/admin/members/${el.dataset.id}/upi-review`, { approve: true }); K.closeModal(); K.toast(t('saved')); K.render(); };
  K.actions['upi-reject'] = async (el) => {
    const note = await K.prompt(t('reject'), t('reason'), t('reject')); if (!note) return;
    await K.post(`/api/admin/members/${el.dataset.id}/upi-review`, { approve: false, note }); K.closeModal(); K.toast(t('saved')); K.render();
  };

  // ======================================================================= entries / teams
  V.entries = async () => {
    const [entries, s] = await Promise.all([K.get('/api/admin/entries'), K.get('/api/admin/settings')]);
    K.state.cache.entries = entries; K.state.cache.settings = s;
    const active = entries.filter((e) => e.status === 'active').length;
    return html`<div class="row sb"><h1>${t('entries_title')} <span class="mut">(${active}/${s.total_entries})</span></h1><button data-act="entry-add">+ ${t('add_entry')}</button></div>
      <p class="mut">${inr(s.monthly_contribution)} × ${s.total_entries} = ${inr(s.monthly_contribution * s.total_entries)} / ${t('month').toLowerCase()}</p>
      ${entries.length ? entries.map((e) => html`<div class="card">
        <div class="row sb"><h2 style="margin:0">${e.label}</h2><span>${chip(e.type === 'team' ? 'gold' : 'none', e.type === 'team' ? t('team') : t('individual'))} ${chip(e.status, t(e.status))} ${e.won ? chip('gold', '🏆') : ''}</span></div>
        ${K.table([{ h: t('name') }, { h: t('phone') }, { h: t('contribution'), num: 1 }, { h: t('prize_percent'), num: 1 }], e.members.map((m) => [m.name, m.phone, inr(m.monthly_share), m.prize_percent + '%']))}
        <div class="row" style="margin-top:.5rem"><button class="sm sec" data-act="entry-edit" data-id="${e.id}">${t('edit')}</button>
        <button class="sm ${e.status === 'active' ? 'danger' : 'sec'}" data-act="entry-status" data-id="${e.id}" data-status="${e.status === 'active' ? 'inactive' : 'active'}">${e.status === 'active' ? t('deactivate') : t('activate')}</button></div></div>`)
        : html`<div class="card"><div class="empty">${t('none')}</div></div>`}`;
  };

  let EF = null; // entry form working state
  const splitEvenly = (total, n) => { const base = Math.floor(total / n); return Array.from({ length: n }, (_, i) => base + (i === 0 ? total - base * n : 0)); };
  const splitPct = (n) => { const base = Math.floor((10000 / n)) / 100; return Array.from({ length: n }, (_, i) => (i === 0 ? Math.round((100 - base * (n - 1)) * 100) / 100 : base)); };
  const readEF = (form) => {
    if (!form) return;
    const d = K.formData(form);
    EF.name = d.name || ''; EF.type = d.type || EF.type;
    EF.rows = EF.rows.map((r, i) => ({ member_id: d['m' + i] ? Number(d['m' + i]) : '', monthly_share: d['s' + i] ?? r.monthly_share, prize_percent: d['p' + i] ?? r.prize_percent }));
  };
  const entryForm = () => {
    const team = EF.type === 'team';
    const memberOpts = [{ value: '', label: '—' }, ...EF.members.filter((m) => m.status === 'active').map((m) => ({ value: m.id, label: `${m.name} (${m.phone})` }))];
    return html`<h2>${EF.id ? t('edit') : t('add_entry')}</h2>
      <form data-submit="entry-save"><div class="form-err"></div>
        ${K.field(t('entry_name'), 'name', { value: EF.name, attrs: 'maxlength="60"' })}
        ${EF.id ? '' : K.select(t('entry_type'), 'type', [{ value: 'individual', label: t('individual') }, { value: 'team', label: t('team') + ' (2–' + EF.settings.max_team_size + ')' }], EF.type, 'data-act="entry-type"')}
        <h3 style="margin-top:1rem">${t('members_in_entry')}</h3>
        <p class="note">${inr(EF.settings.monthly_contribution)} · ${team ? 'contributions must add up to this amount, prize % to 100' : ''}</p>
        ${EF.rows.map((r, i) => html`<div class="card" style="padding:.6rem;margin-bottom:.5rem">
          ${K.select(t('nav_members').replace(/s$/, ''), 'm' + i, memberOpts, r.member_id)}
          ${team ? html`<div class="grid g2"><div>${K.field(t('contribution') + ' ₹', 's' + i, { type: 'number', value: r.monthly_share, attrs: 'min="1" step="1" inputmode="numeric"' })}</div><div>${K.field(t('prize_percent'), 'p' + i, { type: 'number', value: r.prize_percent, attrs: 'min="0.01" max="100" step="0.01" inputmode="decimal"' })}</div></div>` : ''}
        </div>`)}
        ${team ? html`<div class="row"><button type="button" class="sm sec" data-act="entry-equal">${t('split_equally')}</button>${EF.rows.length < EF.settings.max_team_size ? html`<button type="button" class="sm sec" data-act="entry-addrow">+ ${t('add_row')}</button>` : ''}${EF.rows.length > 2 ? html`<button type="button" class="sm danger" data-act="entry-delrow">−</button>` : ''}</div>` : ''}
        <div class="sticky-actions">${modalClose()}<button type="submit">${t('save')}</button></div></form>`;
  };
  const repaint = () => K.modal(entryForm());
  K.actions['entry-add'] = async () => {
    const [members, settings] = await Promise.all([K.get('/api/admin/members'), K.get('/api/admin/settings')]);
    EF = { id: null, type: 'individual', name: '', members, settings, rows: [{ member_id: '', monthly_share: settings.monthly_contribution, prize_percent: 100 }] }; repaint();
  };
  K.actions['entry-edit'] = async (el) => {
    const [members, settings] = await Promise.all([K.get('/api/admin/members'), K.get('/api/admin/settings')]);
    const e = K.state.cache.entries.find((x) => x.id === Number(el.dataset.id));
    EF = { id: e.id, type: e.type, name: e.label, members, settings, rows: e.members.map((m) => ({ member_id: m.member_id, monthly_share: m.monthly_share, prize_percent: m.prize_percent })) }; repaint();
  };
  K.changes['entry-type'] = (el) => {
    readEF(el.form);
    const n = el.value === 'team' ? Math.max(2, EF.rows.length) : 1;
    EF.type = el.value; EF.rows = EF.rows.slice(0, n); while (EF.rows.length < n) EF.rows.push({ member_id: '', monthly_share: '', prize_percent: '' });
    if (EF.type === 'team') { const sh = splitEvenly(EF.settings.monthly_contribution, EF.rows.length), pc = splitPct(EF.rows.length); EF.rows.forEach((r, i) => { r.monthly_share = sh[i]; r.prize_percent = pc[i]; }); }
    repaint();
  };
  K.actions['entry-addrow'] = (el) => { readEF(el.form); EF.rows.push({ member_id: '', monthly_share: '', prize_percent: '' }); repaint(); };
  K.actions['entry-delrow'] = (el) => { readEF(el.form); EF.rows.pop(); repaint(); };
  K.actions['entry-equal'] = (el) => { readEF(el.form); const sh = splitEvenly(EF.settings.monthly_contribution, EF.rows.length), pc = splitPct(EF.rows.length); EF.rows.forEach((r, i) => { r.monthly_share = sh[i]; r.prize_percent = pc[i]; }); repaint(); };
  K.submits['entry-save'] = async (f) => {
    readEF(f);
    const members = EF.rows.map((r) => {
      if (!r.member_id) throw new Error('Choose a member for every row');
      return EF.type === 'team' ? { member_id: r.member_id, monthly_share: Number(r.monthly_share), prize_percent: Number(r.prize_percent) } : { member_id: r.member_id };
    });
    if (EF.id) await K.api('PATCH', `/api/admin/entries/${EF.id}`, { name: EF.name || undefined, members: EF.type === 'individual' ? [{ member_id: members[0].member_id, monthly_share: EF.settings.monthly_contribution, prize_percent: 100 }] : members });
    else await K.post('/api/admin/entries', { type: EF.type, name: EF.name || undefined, members });
    K.closeModal(); K.toast(t('saved')); K.render();
  };
  K.actions['entry-status'] = async (el) => {
    if (el.dataset.status === 'inactive' && !(await K.confirm(t('deactivate'), 'An inactive entry is excluded from future draws.', t('deactivate')))) return;
    await K.api('PATCH', `/api/admin/entries/${el.dataset.id}`, { status: el.dataset.status }); K.toast(t('saved')); K.render();
  };

  // ======================================================================= payments
  V.payments = async () => {
    const st = K.state.payFilter || 'submitted';
    const list = await K.get('/api/admin/payments' + (st === 'all' ? '' : `?status=${st}`));
    if (st === 'submitted') K.state.pendingPayments = list.length;
    return html`<div class="row sb"><h1>${t('payments_title')}</h1><button data-act="pay-record">+ ${t('record_payment')}</button></div>
      ${tabs([['submitted', t('awaiting')], ['verified', t('verified')], ['rejected', t('rejected')], ['all', t('all')]], st, 'pay-filter')}
      <div class="warn">${t('not_proof')}</div>
      ${list.length ? list.map((p) => html`<div class="card">
        <div class="row sb"><b>${p.member_name}</b><b>${inr(p.amount)}</b></div>
        <div class="mut">${p.entry_label} · ${t('month')} ${p.month_no} · ${p.method.toUpperCase()}${p.paid_on ? ' · ' + fdate(p.paid_on) : ''}</div>
        <div style="margin:.3rem 0">${t('txn_ref')}: <span class="mono">${p.txn_ref || '—'}</span> ${chip(p.status, t(p.status))} ${p.submitted_by === 'admin' ? chip('gold', 'admin') : ''}</div>
        ${p.reject_reason ? html`<div class="note">${t('reason')}: ${p.reject_reason}</div>` : ''}
        <div class="row" style="margin-top:.4rem">${p.status === 'submitted' ? html`<button class="sm" data-act="pay-verify" data-id="${p.id}">✔ ${t('verify')}</button>` : ''}
        ${p.status !== 'rejected' ? html`<button class="sm danger" data-act="pay-reject" data-id="${p.id}" data-verified="${p.status === 'verified' ? 1 : 0}">${p.status === 'verified' ? 'Reverse' : t('reject')}</button>` : ''}</div></div>`)
        : html`<div class="card"><div class="empty">${t('none')}</div></div>`}`;
  };
  K.actions['pay-filter'] = (el) => { K.state.payFilter = el.dataset.v; K.render(); };
  K.actions['pay-verify'] = async (el) => {
    if (!(await K.confirm(t('verify'), 'Confirm that you have checked this transaction reference in your bank / UPI statement and the money was received.', t('verify')))) return;
    await K.post(`/api/admin/payments/${el.dataset.id}/verify`); K.toast(t('saved')); K.render();
  };
  K.actions['pay-reject'] = async (el) => {
    const reason = await K.prompt(el.dataset.verified === '1' ? 'Reverse verified payment' : t('reject'), t('reason'), t('reject')); if (!reason) return;
    await K.post(`/api/admin/payments/${el.dataset.id}/reject`, { reason }); K.toast(t('saved')); K.render();
  };
  let RP = null;
  const recordForm = () => {
    const e = RP.entries.find((x) => x.id === Number(RP.entry_id)) || RP.entries[0];
    return html`<h2>${t('record_payment')}</h2><form data-submit="pay-record"><div class="form-err"></div>
      ${K.select(t('entry'), 'entry_id', RP.entries.filter((x) => x.status === 'active').map((x) => ({ value: x.id, label: x.label })), e?.id, 'data-act="rec-entry"')}
      ${K.select(t('record_for'), 'member_id', (e?.members || []).map((m) => ({ value: m.member_id, label: `${m.name} · ${inr(m.monthly_share)}` })), e?.members[0]?.member_id)}
      ${K.select(t('month'), 'month_no', RP.months.map((m) => ({ value: m.month_no, label: `${t('month')} ${m.month_no} · ${fdate(m.due_date)}` })), RP.month_no)}
      ${K.field(t('amount') + ' (₹)', 'amount', { type: 'number', required: true, attrs: 'min="1" step="1" inputmode="numeric"' })}
      ${K.select(t('method'), 'method', [{ value: 'cash', label: t('method_cash') }, { value: 'upi', label: t('method_upi') }, { value: 'bank', label: t('method_bank') }, { value: 'gateway', label: t('method_gateway') }], 'cash')}
      ${K.field(t('txn_ref') + ' (cash: optional)', 'txn_ref', { attrs: 'maxlength="40" autocomplete="off"' })}
      ${K.field(t('paid_date'), 'paid_on', { type: 'date', value: RP.today })}
      ${K.field('Note', 'note')}
      <div class="sticky-actions">${modalClose()}<button type="submit">${t('save')}</button></div></form>`;
  };
  K.actions['pay-record'] = async () => {
    const [entries, months] = await Promise.all([K.get('/api/admin/entries'), K.get('/api/admin/months')]);
    if (!months.length) throw new Error(t('setup_cycle_hint'));
    const today = new Date().toISOString().slice(0, 10);
    const cur = months.filter((m) => m.due_date <= today).pop() || months[0];
    RP = { entries, months, entry_id: entries.find((e) => e.status === 'active')?.id, month_no: cur.month_no, today };
    if (!RP.entry_id) throw new Error('Create an entry first');
    K.modal(recordForm());
  };
  K.changes['rec-entry'] = (el) => { const d = K.formData(el.form); RP.entry_id = Number(el.value); RP.month_no = d.month_no; K.modal(recordForm()); };
  K.submits['pay-record'] = async (f, d) => {
    await K.post('/api/admin/payments/record', { entry_id: d.entry_id, member_id: Number(d.member_id), month_no: Number(d.month_no), amount: d.amount, method: d.method, txn_ref: d.txn_ref, paid_on: d.paid_on, note: d.note });
    K.closeModal(); K.toast(t('saved')); K.render();
  };

  // ======================================================================= settings
  V.settings = async () => {
    const [s, months] = await Promise.all([K.get('/api/admin/settings'), K.get('/api/admin/months')]);
    const num = (label, name, extra = '') => K.field(label, name, { type: 'number', value: s[name], required: true, attrs: `step="1" inputmode="numeric" ${extra}` });
    const chk = (label, name) => html`<label class="chk"><input type="checkbox" name="${name}" ${s[name] ? K.raw('checked') : ''}> <span>${label}</span></label>`;
    return html`<h1>${t('settings_title')}</h1>
      <div class="card"><form data-submit="settings-save"><div class="form-err"></div>
        <h2>KURI</h2>
        <div class="grid g2">${num('Total entries', 'total_entries', 'min="1"')}${num('Monthly contribution per entry (₹)', 'monthly_contribution', 'min="1"')}
        ${num('Duration (months)', 'duration_months', 'min="1" max="120"')}${num('Winning entries per draw', 'winning_entries_per_draw', 'min="1"')}</div>
        ${num('Prize amount (₹)', 'prize_amount', 'min="0"')}
        <p class="note">= ${inr(s.total_entries * s.monthly_contribution)} / month collection (${s.total_entries} × ${inr(s.monthly_contribution)})</p>
        <h2 style="margin-top:1rem">Dates</h2>
        ${K.field('First due date (start of cycle)', 'start_date', { type: 'date', value: s.start_date })}
        <div class="grid g2">${num('Payment due day of month (1–28)', 'due_day', 'min="1" max="28"')}${num('Draw day of month (1–28)', 'draw_day', 'min="1" max="28"')}</div>
        <h2 style="margin-top:1rem">Rules &amp; eligibility</h2>
        ${chk('Entries that have already won are not eligible again', 'one_win_per_entry')}
        ${chk('Only fully-paid entries (all months up to the draw month) are eligible', 'require_paid_for_draw')}
        ${chk('Run draws automatically on the draw date (server-side)', 'auto_draw')}
        <div class="grid g2">${num('Max people in a team (2–4)', 'max_team_size', 'min="2" max="4"')}${num('Max entries per person', 'max_entries_per_member', 'min="1"')}</div>
        ${K.select('Winner privacy for members', 'winner_privacy', [{ value: 'masked', label: 'Masked names (Ab••• Cd•••)' }, { value: 'full', label: 'Full names' }, { value: 'entry_only', label: 'Entry label only' }], s.winner_privacy)}
        <label for="f-rules_en">Rules (English)</label><textarea id="f-rules_en" name="rules_en" maxlength="5000">${s.rules_en}</textarea>
        <label for="f-rules_ml">നിയമങ്ങൾ (മലയാളം)</label><textarea id="f-rules_ml" name="rules_ml" maxlength="5000">${s.rules_ml}</textarea>
        <h2 style="margin-top:1rem">Collection account &amp; reminders</h2>
        ${K.field('Collection UPI ID (shown to members)', 'collection_upi_id', { value: s.collection_upi_id, placeholder: 'kuri@bank' })}
        ${K.field('Payee name', 'collection_payee_name', { value: s.collection_payee_name })}
        <div class="grid g2">${num('Reminder send hour (0–23, local)', 'reminder_hour', 'min="0" max="23"')}${num('Default reminder period (months)', 'reminder_default_months', 'min="1" max="60"')}</div>
        <button class="block" type="submit" style="margin-top:1rem">${t('save_changes')}</button></form></div>
      <div class="card"><h2>Monthly cycle</h2>
        ${months.length ? K.table([{ h: t('month') }, { h: t('due_date') }, { h: t('draw_title') }, { h: '' }], months.map((m) => [m.month_no, fdate(m.due_date), fdate(m.draw_date),
          m.draw_id ? chip('completed', 'Drawn') : html`<button class="sm sec" data-act="month-edit" data-id="${m.month_no}" data-due="${m.due_date}" data-draw="${m.draw_date}">${t('edit')}</button>`]))
          : html`<p class="mut">${t('setup_cycle_hint')}</p>`}
        <button class="${months.length ? 'sec' : ''}" data-act="cycle-generate" style="margin-top:.6rem">${months.length ? 'Regenerate cycle from settings' : 'Generate cycle'}</button>
        <p class="note">Regeneration is blocked once any payment or draw exists.</p></div>`;
  };
  K.submits['settings-save'] = async (f, d) => {
    for (const k of ['rules_en', 'rules_ml']) d[k] = d[k] ?? '';
    await K.api('PUT', '/api/admin/settings', d); K.toast(t('saved')); K.render();
  };
  K.actions['cycle-generate'] = async () => {
    if (!(await K.confirm('Generate cycle', 'Creates the monthly due and draw dates from the first due date in Settings. Save settings first.', 'Generate'))) return;
    await K.post('/api/admin/cycle/generate'); K.toast(t('saved')); K.render();
  };
  K.actions['month-edit'] = (el) => K.modal(html`<h2>${t('month')} ${el.dataset.id}</h2><form data-submit="month-save" data-id="${el.dataset.id}"><div class="form-err"></div>
    ${K.field(t('due_date'), 'due_date', { type: 'date', value: el.dataset.due, required: true })}${K.field(t('draw_title'), 'draw_date', { type: 'date', value: el.dataset.draw, required: true })}
    <div class="sticky-actions">${modalClose()}<button type="submit">${t('save')}</button></div></form>`);
  K.submits['month-save'] = async (f, d) => { await K.api('PATCH', `/api/admin/months/${f.dataset.id}`, d); K.closeModal(); K.toast(t('saved')); K.render(); };
})();
