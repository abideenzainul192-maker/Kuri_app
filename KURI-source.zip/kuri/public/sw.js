/* KURI service worker: caches the app shell for fast, installable, offline-tolerant loading.
   API calls are NEVER cached (money data must always be live). */
const CACHE = 'kuri-shell-v2';
const SHELL = ['/', '/styles.css', '/js/i18n.js', '/js/core.js', '/js/member.js', '/js/admin.js', '/js/admin2.js', '/js/main.js', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/logo.svg'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/') || u.pathname.startsWith('/webhooks/')) return;
  // network-first so updates arrive quickly; fall back to cache when offline
  e.respondWith(fetch(e.request).then((res) => {
    if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
    return res;
  }).catch(() => caches.match(e.request).then((m) => m || caches.match('/'))));
});
