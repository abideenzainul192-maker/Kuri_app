# KURI — monthly pooled-savings (chit-style) manager

Installable mobile-first PWA (Android, iPhone, tablet, desktop) with a real backend and database.
English + Malayalam. Emerald-and-gold design.

> **Before real money moves:** pooled-savings / chit schemes are regulated in India (Chit Funds Act, 1982 and state rules).
> This software does **not** make you compliant. Read [docs/COMPLIANCE.md](docs/COMPLIANCE.md).

## Try it in one minute

Requires **Node.js 22.5+** (nothing else to install: SQLite is built in, zero npm dependencies).
Python 3 with `openpyxl` and `reportlab` is only needed for Excel/PDF exports.

```bash
npm run demo          # starts http://localhost:3000 with sample members, teams and payments
```

- Admin: tab **Admin**, phone `9000000001`, password `DemoAdmin2026!`
- Member: tab **Member**, phone `9847000010` — the OTP is shown on screen in demo mode only

Real run: `cp .env.example .env`, edit, then `npm start` — see [docs/SETUP.md](docs/SETUP.md).
Tests: `npm test` (18 end-to-end API tests).

## Documentation

| | |
|---|---|
| [docs/SETUP.md](docs/SETUP.md) | Local setup, configuration, WhatsApp + OTP setup |
| [docs/DEPLOY.md](docs/DEPLOY.md) | Production deployment, HTTPS, backups, restore |
| [docs/INSTALL_PHONES.md](docs/INSTALL_PHONES.md) | Installing on Android and iPhone; member quick-guide |
| [docs/FEATURES.md](docs/FEATURES.md) | What is fully working vs what needs an external service |
| [docs/SECURITY.md](docs/SECURITY.md) | Security design and its honest limits |
| [docs/COMPLIANCE.md](docs/COMPLIANCE.md) | Legal / regulatory checklist (not legal advice) |
| [docs/schema.sql](docs/schema.sql) | Complete database schema |

## Stack

Node.js 22 (`http`, `node:sqlite`, `crypto`) · SQLite (WAL) · vanilla JS PWA (no build step) · Python `openpyxl`/`reportlab` for exports · Meta WhatsApp Cloud API.
Chosen so there is nothing to compile and very little to break: one process, one data folder.

## Layout

```
server.js            HTTP server, routes, scheduler (reminders, auto-draw, daily backup)
lib/db.js            schema + default settings      lib/core.js      auth, sessions, OTP, audit chain
lib/services.js      members, entries/teams, payments, UPI review, dashboard
lib/draw.js          secure draw, verification, prizes      lib/reminders.js  WhatsApp reminder engine
lib/whatsapp.js      WhatsApp Cloud API client      lib/reports.js + scripts/export.py   reports, Excel, PDF
public/              the PWA (index.html, js/*, styles.css, sw.js, manifest, icons)
scripts/             demo.js, restore.js, export.py          test/   API test suite
```
