#!/usr/bin/env python3
"""Reads a report as JSON on stdin, writes an .xlsx or .pdf to stdout.  usage: export.py xlsx|pdf"""
import sys, json, io

fmt = sys.argv[1]
rep = json.load(sys.stdin)
cols, rows = rep["columns"], rep["rows"]
EMERALD, GOLD = "0B5D45", "D4A017"

if fmt == "xlsx":
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    wb = Workbook(); ws = wb.active; ws.title = rep["title"][:31]
    ws.append([rep["title"]]); ws["A1"].font = Font(bold=True, size=14, color=EMERALD)
    ws.append(["Generated " + rep["generated"] + (" | " + rep["note"] if rep.get("note") else "")])
    ws.append([])
    ws.append(cols)
    for c in ws[4]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor=EMERALD); c.alignment = Alignment(wrap_text=True, vertical="center")
    for r in rows:
        # keep numbers numeric; guard against spreadsheet formula injection in text cells
        ws.append([("'" + v if isinstance(v, str) and v[:1] in "=+-@" else v) for v in r])
    for i, c in enumerate(cols, 1):
        width = max([len(str(c))] + [len(str(r[i - 1])) for r in rows[:200] if i - 1 < len(r)])
        ws.column_dimensions[get_column_letter(i)].width = min(max(10, width + 2), 48)
    ws.freeze_panes = "A5"
    buf = io.BytesIO(); wb.save(buf); sys.stdout.buffer.write(buf.getvalue())

elif fmt == "pdf":
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    font = "Helvetica"; rupee = "Rs."
    try:  # DejaVu has the rupee sign; fall back to "Rs." if unavailable
        pdfmetrics.registerFont(TTFont("DejaVu", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
        pdfmetrics.registerFont(TTFont("DejaVu-Bold", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
        font = "DejaVu"; rupee = "₹"
    except Exception:
        pass
    def clean(v):
        s = "" if v is None else str(v)
        if font == "Helvetica": s = s.replace("₹", "Rs.")
        # Malayalam and other scripts need a font that is not bundled; replace to avoid blank boxes
        return "".join(ch if ord(ch) < 0x0D00 or ord(ch) > 0x0D7F else "?" for ch in s)
    st = getSampleStyleSheet()
    cell = ParagraphStyle("c", parent=st["BodyText"], fontName=font, fontSize=7.5, leading=9)
    head = ParagraphStyle("h", parent=cell, textColor=colors.white, fontName=("DejaVu-Bold" if font == "DejaVu" else "Helvetica-Bold"))
    title = ParagraphStyle("t", parent=st["Title"], fontName=font, textColor=colors.HexColor("#" + EMERALD), alignment=0)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=24, rightMargin=24, topMargin=28, bottomMargin=28, title=rep["title"])
    els = [Paragraph("KURI - " + clean(rep["title"]), title),
           Paragraph(clean("Generated " + rep["generated"] + (" | " + rep["note"] if rep.get("note") else "")), cell), Spacer(1, 8)]
    data = [[Paragraph(clean(c), head) for c in cols]] + [[Paragraph(clean(v), cell) for v in r] for r in rows]
    if not rows: data.append([Paragraph("No records", cell)] + [""] * (len(cols) - 1))
    t = Table(data, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#" + EMERALD)),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F6F1E0")]),
                           ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#C9B77A")), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    els.append(t); doc.build(els); sys.stdout.buffer.write(buf.getvalue())
else:
    sys.exit("unknown format")
