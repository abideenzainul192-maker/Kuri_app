'use strict';
// Restore KURI from a backup file.
//   npm run restore -- data/backups/kuri-2026-11-22T02-00-00-auto.db
// STOP the server first. The current database is moved aside (never deleted) before the backup is put in place.
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const DATA_DIR = process.env.KURI_DATA_DIR || path.join(__dirname, '..', 'data');
const src = process.argv[2];
if (!src) { console.error('Usage: npm run restore -- <backup-file.db>'); process.exit(1); }
const srcPath = path.resolve(src);
if (!fs.existsSync(srcPath)) { console.error('Backup not found:', srcPath); process.exit(1); }

// Validate the backup before touching anything
try {
  const chk = new DatabaseSync(srcPath, { readOnly: true });
  const ok = chk.prepare('PRAGMA integrity_check').get();
  const tables = chk.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((r) => r.name);
  chk.close();
  if (Object.values(ok)[0] !== 'ok') throw new Error('integrity_check failed');
  for (const need of ['members', 'entries', 'payments', 'draws', 'audit_log']) if (!tables.includes(need)) throw new Error('missing table ' + need);
} catch (e) { console.error('This file is not a valid KURI backup:', e.message); process.exit(1); }

const dbFile = path.join(DATA_DIR, 'kuri.db');
fs.mkdirSync(DATA_DIR, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
let movedAside = null;
if (fs.existsSync(dbFile)) {
  movedAside = `kuri.before-restore-${stamp}.db`;
  fs.renameSync(dbFile, path.join(DATA_DIR, `kuri.before-restore-${stamp}.db`));
  for (const ext of ['-wal', '-shm']) if (fs.existsSync(dbFile + ext)) fs.renameSync(dbFile + ext, path.join(DATA_DIR, `kuri.before-restore-${stamp}.db${ext}`));
}
fs.copyFileSync(srcPath, dbFile);
fs.chmodSync(dbFile, 0o600);
console.log(`Restored ${srcPath} -> ${dbFile}`);
if (movedAside) console.log(`Previous database kept as ${movedAside}`);
console.log('Note: uploaded QR images live in data/uploads and are not part of the .db backup - restore that folder from your file backup too.');
