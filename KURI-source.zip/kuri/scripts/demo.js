'use strict';
// One-command PREVIEW with sample data:  npm run demo
// Starts KURI on http://localhost:3000 using a throw-away database in ./data-demo, seeded with sample
// members, teams and payments. OTPs are shown on screen (preview mode only - never use with real members).
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || '3000';
const base = `http://localhost:${PORT}`;
const dataDir = path.join(__dirname, '..', 'data-demo');
fs.rmSync(dataDir, { recursive: true, force: true });

const ADMIN_PW = 'DemoAdmin2026';
const child = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'server.js')], {
  env: { ...process.env, PORT, KURI_DATA_DIR: dataDir, KURI_DEV_OTP: '1', ADMIN1_PHONE: '9000000001', ADMIN2_PHONE: '9000000002', ADMIN_INITIAL_PASSWORD: ADMIN_PW },
  stdio: ['ignore', 'ignore', 'inherit'],
});
const stop = () => { try { child.kill(); } catch (_) {} process.exit(0); };
process.on('SIGINT', stop); process.on('SIGTERM', stop);

let cookie = '';
async function api(method, url, body) {
  const r = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'kuri', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
  const j = await r.json().catch(() => null);
  if (!r.ok) throw new Error(`${method} ${url}: ${j?.error || r.status}`);
  return j;
}

(async () => {
  for (let i = 0; i < 50; i++) { try { if ((await fetch(base + '/api/health')).ok) break; } catch (_) {} await new Promise((r) => setTimeout(r, 200)); }
  await api('POST', '/api/auth/admin/login', { phone: '9000000001', password: ADMIN_PW });
  await api('POST', '/api/auth/admin/change-password', { current: ADMIN_PW, new: 'DemoAdmin2026!' });
  const now = new Date();
  const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 2, 5)).toISOString().slice(0, 10);
  await api('PUT', '/api/admin/settings', { start_date: start, total_entries: 20, monthly_contribution: 20000, duration_months: 20, prize_amount: 400000, collection_upi_id: 'demo@bank', collection_payee_name: 'KURI Demo' });
  await api('POST', '/api/admin/cycle/generate');
  const names = ['Anil Kumar', 'Beena Thomas', 'Cherian Joseph', 'Divya Nair', 'Eldho Paul', 'Fathima Beevi', 'George Mathew', 'Hari Menon'];
  const ms = [];
  for (let i = 0; i < names.length; i++) ms.push(await api('POST', '/api/admin/members', { name: names[i], phone: '98470000' + (10 + i), address: 'Kochi, Kerala', language: i % 2 ? 'en' : 'ml', whatsapp_opt_in: i < 3 }));
  const e1 = await api('POST', '/api/admin/entries', { type: 'individual', members: [{ member_id: ms[0].id }] });
  const e2 = await api('POST', '/api/admin/entries', { type: 'individual', members: [{ member_id: ms[1].id }] });
  const e3 = await api('POST', '/api/admin/entries', { type: 'team', name: 'Family Team', members: ms.slice(2, 6).map((m) => ({ member_id: m.id, monthly_share: 5000, prize_percent: 25 })) });
  const e4 = await api('POST', '/api/admin/entries', { type: 'team', name: 'Friends Pair', members: [{ member_id: ms[6].id, monthly_share: 12000, prize_percent: 60 }, { member_id: ms[7].id, monthly_share: 8000, prize_percent: 40 }] });
  for (const mo of [1, 2]) for (const en of [e1, e2, e3]) for (const m of en.members) await api('POST', '/api/admin/payments/record', { entry_id: en.id, member_id: m.member_id, month_no: mo, amount: m.monthly_share, method: 'upi', txn_ref: `DEMO${mo}${en.id}${m.member_id}000` });
  await api('POST', '/api/admin/payments/record', { entry_id: e4.id, member_id: ms[6].id, month_no: 1, amount: 6000, method: 'cash' });
  console.log(`
  ┌──────────────────────────────────────────────────────────────┐
  │  KURI demo is running:  ${base.padEnd(36)}│
  ├──────────────────────────────────────────────────────────────┤
  │  Admin   : tab "Admin" · phone 9000000001 · DemoAdmin2026!   │
  │  Member  : tab "Member" · phone 9847000010 (OTP shown on     │
  │            screen in demo mode)                              │
  │  Sample  : 8 members, 2 individual + 2 team entries          │
  │  Stop    : Ctrl+C   (demo data is in ./data-demo)            │
  └──────────────────────────────────────────────────────────────┘`);
})().catch((e) => { console.error('Demo setup failed:', e.message); stop(); });
